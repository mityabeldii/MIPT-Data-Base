USE [AGENCY]
GO

DROP USER testuser
DROP LOGIN testlog

CREATE LOGIN testlog WITH PASSWORD = 'testlog'
CREATE USER testuser FOR LOGIN testlog

DENY  SELECT, INSERT, UPDATE ON hotels TO testuser
GRANT SELECT, INSERT, UPDATE ON hotels TO testuser

DENY  SELECT(country_id), UPDATE(country_id) ON resort TO testuser
GRANT SELECT(country_id), UPDATE(country_id) ON resort TO testuser

DENY  SELECT(price) ON offer TO testuser
GRANT SELECT(price) ON offer TO testuser

DENY  SELECT ON laba5_1 TO testuser
GRANT SELECT ON laba5_1 TO testuser

EXEC sp_droprolemember 'testrole', 'testuser'
DROP ROLE testrole
CREATE ROLE testrole
GRANT  SELECT ON laba5_8 TO testrole
GRANT  UPDATE(country) ON laba5_8 TO testrole
EXEC sp_addrolemember testrole, testuser

EXECUTE AS USER = 'testuser'

UPDATE hotels SET classifiacation = classifiacation - 1


UPDATE laba5_8 SET country = '������'
WHERE country = 'qwe'
SELECT * FROM laba5_8

REVERT