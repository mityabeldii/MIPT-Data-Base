INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Khortitsa Palace Hotel',1,89,'KhortitsaPalaceHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Inturist',1,78,'Inturist@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Отель Украина',2,75,'ОтельУкраина@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Арт-отель Баккара',2,81,'АртотельБаккара@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('ALFAVITO Kyiv Hotel',2,89,'ALFAVITOKyivHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Дворик у Причала',3,78,'ДворикуПричала@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Гостевой Дом Тавр',3,87,'ГостевойДомТавр@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Villa Bonne Maison with Garden',4,86,'VillaBonneMaisonwithGarden@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Riviera Sunrise Resort & SPA',4,86,'RivieraSunriseResortSPA@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Отель Фраполли',5,90,'ОтельФраполли@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Дюк Отель',5,92,'ДюкОтель@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Курортный комплекс Аквамарин',6,81,'КурортныйкомплексАквамарин@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Отель Песочная Бухта ',6,81,'ОтельПесочнаяБухта@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Космос',7,73,'Космос@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Отель Восход',7,77,'ОтельВосход@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Гостиница Измайлово Гамма',7,84,'ГостиницаИзмайловоГамма@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Гостиница Коринтия Санкт-Петербург',8,87,'ГостиницаКоринтияСанктПетербург@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Majestic Boutique Hotel Deluxe',8,92,'MajesticBoutiqueHotelDeluxe@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Отель Ibis Нижний Новгород',9,84,'ОтельIbisНижнийНовгород@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Отель Ibis Нижний Новгород',9,81,'ОтельIbisНижнийНовгород@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Royal Olympic Hotel',10,83,'RoyalOlympicHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Best Western My Athens Hotel',10,73,'BestWesternMyAthensHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Villa Madeleine',11,93,'VillaMadeleine@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Portes Beach Hotel',11,81,'PortesBeachHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Dionysos Hotel',12,87,'DionysosHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Villas Duc - Rhodes',12,89,'VillasDucRhodes@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Lyttos Beach',13,90,'LyttosBeach@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Kiani Beach Family Resort- All Inclusive',13,85,'KianiBeachFamilyResortAllInclusive@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Mykonos Blanc',14,92,'MykonosBlanc@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Aegean Land (ex Palace)',14,83,'AegeanLand@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Olive Green Hotel',15,95,'OliveGreenHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Lato Boutique Hotel',15,87,'LatoBoutiqueHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('GDM Megaron Hotel',15,94,'GDMMegaronHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Cecilia Hostel',16,86,'CeciliaHostel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Guardian Guest House',16,88,'GuardianGuestHouse@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Sharm El Sheikh Marriott Resort',17,72,'SharmElSheikhMarriottResort@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Sunrise Arabian Beach Resort',17,88,'SunriseArabianBeachResort@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Four Seasons Cairo At The First Residence',18,85,'FourSeasonsCairoAtTheFirstResidence@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Best View Pyramids Hotel',18,87,'BestViewPyramidsHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Maritim Jolie Ville Kings Island',19,92,'MaritimJolieVilleKingsIsland@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Achti Resort',19,83,'AchtiResort@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hurghada Dreams Hotel Apartment',20,77,'HurghadaDreamsHotelApartment@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Baiyoke Sky Hotel',21,74,'BaiyokeSkyHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Chatrium Hotel Riverside Bangkok',21,90,'ChatriumHotelRiversideBangkok@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Eastin Grand Hotel Sathorn',21,93,'EastinGrandHotelSathorn@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('The Memory at On On Hotel',22,86,'TheMemoryatOnOnHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Casa Blanca Boutique Hotel',22,90,'CasaBlancaBoutiqueHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Meroom',22,90,'Meroom@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Amari Ocean Pattaya',23,85,'AmariOceanPattaya@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Royal Cliff Grand Hotel by Royal Cliff Hotels Group',23,87,'RoyalCliffGrandHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Santiburi Beach Resort & Spa',24,93,'SantiburiBeachResortSpa@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Sensimar Koh Samui – Adults Only Resort',24,96,'SensimarKohSamui–AdultsOnlyResort@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Banyan Tree Samui',24,92,'BanyanTreeSamui@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Seven Hills Tower',25,88,'SevenHillsTower@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('ITC Mughal A Luxury Collection Hotel Agra',25,84,'ITCMughalALuxuryCollectionHotelAgra@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hotel City Star',26,86,'HotelCityStar@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('The Prime Balaji Deluxe',26,81,'ThePrimeBalajiDeluxe@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('The Leela Goa',27,90,'TheLeelaGoa@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Vivanta by Taj Holiday Village',27,85,'VivantabyTajHolidayVillage@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Purity',28,92,'Purity@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Kochi Marriott Hotel',28,91,'KochiMarriottHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Carnoustie Ayurveda & Wellness Resort',28,86,'CarnoustieAyurvedaWellnessResort@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Grand Nikko Tokyo Daiba',29,91,'GrandNikkoTokyoDaiba@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Royal Park Hotel The Shiodome',29,89,'RoyalParkHotelTheShiodome@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Mitsui Garden Hotel Ginza Premier',29,88,'MitsuiGardenHotelGinzaPremier@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hotel Edit Yokohama',30,87,'HotelEditYokohama@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Daiwa Roynet Hotel Yokohama-Koen',30,86,'DaiwaRoynetHotelYokohamaKoen@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hotel Gran Ms Kyoto',31,85,'HotelGranMsKyoto@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('HOTEL MYSTAYS Kyoto Shijo',31,84,'HOTELMYSTAYSKyotoShijo@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Piece Hostel Sanjo',31,93,'PieceHostelSanjo@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('HOTEL MYSTAYS Sakaisuji Honmachi',32,79,'HOTELMYSTAYSSakaisujiHonmachi@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Daiwa Roynet Hotel Osaka-Kitahama',32,88,'DaiwaRoynetHotelOsakaKitahama@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Mitsui Garden Hotel Osaka Premier',32,88,'MitsuiGardenHotelOsakaPremier@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Warwick Paris (Former Warwick Champs-Elysees)',33,81,WarwickPars('FormerWarwickChampsElysees)@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Pullman Paris Montparnasse',33,83,'PullmanParisMontparnasse@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hôtel California Champs Elysées',33,81,'HôtelCaliforniaChampsElysées@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Golden Tulip Bercy Gare de Lyon 209',33,83,'GoldenTulipBercyGaredeLyon209@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hotel Du Louvre, a Hyatt Hotel,33',33,83,'HotelDuLouve@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Appartements - Le Logis Versaillais',34,95,'AppartementsLeLogisVersaillais@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hôtel du Jeu de Paume',34,88,'HôtelduJeudePaume@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hôtel Fitz Roy',35,87,'HôtelFitzRoy@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hôtel Alpen Ruitor',35,90,'HôtelAlpenRuitor@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hôtel L_Heliopic Sweet and Spa',36,9.1,'HôteLHeliopicSweetandSpa@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Chalet Hôtel Le Prieuré',36,86,'ChaletHôtelLePrieuré@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Boutique Hotel Le Morgane',36,89,'BoutiqueHotelLeMorgane@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hôtel Mont-Blanc Chamonix',36,93,'HôtelMontBlancChamonix@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Eurostars Grand Marina Hotel GL',37,86,'EurostarsGrandMarinaHotelGL@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Catalonia Sagrada Familia',37,81,'CataloniaSagradaFamilia@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Royal Passeig de Gracia',37,86,'RoyalPasseigdeGracia@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Majestic Hotel & Spa Barcelona GL',37,90,'MajesticHotelSpaBarcelonaGL@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Toc Hostel Madrid',38,90,'TocHostelMadrid@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hotel Liabeny',38,89,'HotelLiabeny@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Preciados',38,90,'Preciados@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Melia Sierra Nevada',39,83,'MeliaSierraNevada@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Gran Meliá Don Pepe',39,83,'GranMeliáDonPepe@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Inside Plaza Sierra Nevada',39,84,'InsidePlazaSierraNevada@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Adrián Hoteles Jardines de Nivaria',40,90,'AdriánHotelesJardinesdeNivaria@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hotel Suite Villa María',40,91,'HotelSuiteVillaMaría@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('H10 Costa Adeje Palace',40,82,'H10CostaAdejePalace@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Iberostar Las Dalias - All Inclusive',40,84,'IberostarLasDaliasAllInclusive@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Iberostar Grand Hotel El Mirador - Adults Only',40,93,'IberostarGrandHotelElMiradorAdultsOnly@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Welcome Piram Hotel',41,81,'WelcomePiramHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hotel Quirinale',41,83,'HotelQuirinale@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hotel Nord Nuova Roma',41,83,'HotelNordNuovaRoma@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('NH Collection Milano President',42,87,'NHCollectionMilanoPresident@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hotel Da Vinci',42,80,'HotelDaVinci@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Rosa Grand Milano - Starhotels Collezione',42,86,'RosaGrandMilanoStarhotelsCollezione@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('The Square Milano Duomo',42,89,'TheSquareMilanoDuomo@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hotel Ala',43,86,'HotelAla@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hotel Bonvecchiati',43,82,'HotelBonvecchiati@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Pesaro Palace',43,87,'PesaroPalace@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hotel Belle Epoque',43,77,'HotelBelleEpoque@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hilton Molino Stucky Venice',43,82,'HiltonMolinoStuckyVenice@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Plus Florence',44,83,'PlusFlorence@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Wow Florence Hostel',44,84,'WowFlorenceHostel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hostel Archi Rossi',44,85,'HostelArchiRossi@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('FH Hotel Calzaiuoli',44,87,'FHHotelCalzaiuoli@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('B&B Le Stanze del Duomo',44,91,'BBLeStanzedelDuomo@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Meliá Brasil 21',45,86,'MeliáBrasil21@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Windsor Brasília Hotel',45,94,'WindsorBrasíliaHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Athos Bulcão Hplus Executive',45,88,'AthosBulcãoHplusExecutive@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Manhattan Plaza',45,87,'ManhattanPlaza@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Américas Copacabana Hotel',46,87,'AméricasCopacabanaHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Golden Tulip Rio Copacabana',46,81,'GoldenTulipRioCopacabana@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Royal Rio Palace Hotel',46,80,'RoyalRioPalaceHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Tulip Inn Rio Copacabana',46,81,'TulipInnRioCopacabana@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Bahiacafé Hotel',47,88,'BahiacaféHotel@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Pousada do Boqueirão',47,92,'PousadadoBoqueirão@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Pousada Solar dos Deuses',47,96,'PousadaSolardosDeuses@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])
VALUES('Hotel Casa do Amarelindo',47,93,'HotelCasadoAmarelindo@mymail.com')
GO