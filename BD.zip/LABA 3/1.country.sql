INSERT INTO [dbo].[country] ([name]) VALUES ('Украина')
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Россия')
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Египет')
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Таиланд')
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Греция')
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Индия')
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Япония')
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Франция')
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Испания')
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Италия')
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Бразилия')
GO