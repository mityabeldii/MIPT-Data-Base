INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(1,'place','feature',96,6)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(1,'place','feature',96,7)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(1,'place','feature',96,8)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(1,'place','feature',96,9)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(1,'place','feature',96,10)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(1,'place','feature',96,11)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(1,'place','feature',96,12)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(1,'place','feature',96,13)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',49,33)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',49,34)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',82,33)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',82,34)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',49,35)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',49,36)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',82,35)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',82,36)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',49,37)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',49,38)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',82,37)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',82,38)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',49,39)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',49,40)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',82,39)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',82,40)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',49,41)
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id])
     VALUES(3,'place','feature',82,41)
GO