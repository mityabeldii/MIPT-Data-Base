CREATE TABLE [resort] (
	resort_id int IDENTITY(1,1),
	country_id int,
	place varchar(50),
	feature varchar(50),
	sea_id int,
	hotel_id int,
  CONSTRAINT [PK_RESORT] PRIMARY KEY CLUSTERED
  (
  [resort_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
CREATE TABLE [offer] (
	offer_id int IDENTITY(1,1),
	resort_id int,
	client_id int,
	price money,
	discount real,
	start_date date,
	end_date date,
  CONSTRAINT [PK_OFFER] PRIMARY KEY CLUSTERED
  (
  [offer_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
CREATE TABLE [client] (
	client_id int IDENTITY(1,1),
	first_name varchar(50),
	last_name varchar(50),
	city_id int,
	phone_number varchar(50),
	email varchar(50),
	adress varchar(50),
	passport varchar(50),
	foreign_passport varchar(50),
	birth_date date,
  CONSTRAINT [PK_CLIENT] PRIMARY KEY CLUSTERED
  (
  [client_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
CREATE TABLE [country] (
	country_id int IDENTITY(1,1),
	name varchar(50),
  CONSTRAINT [PK_COUNTRY] PRIMARY KEY CLUSTERED
  (
  [country_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
CREATE TABLE [city] (
	city_id int IDENTITY(1,1),
	country_id int,
	name varchar(50),
  CONSTRAINT [PK_CITY] PRIMARY KEY CLUSTERED
  (
  [city_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
CREATE TABLE [seas] (
	sea_id int IDENTITY(1,1),
	name varchar(50),
  CONSTRAINT [PK_SEAS] PRIMARY KEY CLUSTERED
  (
  [sea_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
CREATE TABLE [hotels] (
	hotel_id int IDENTITY(1,1),
	name varchar(50),
	city_id int,
	classifiacation int,
	web_site varchar(50),
  CONSTRAINT [PK_HOTELS] PRIMARY KEY CLUSTERED
  (
  [hotel_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
CREATE TABLE [accompanying] (
	offer_id int,
	client_id int,
	discount real 
)
GO
CREATE TABLE [seas_countries] (
	sea_id int,
	country_id int 
)
GO
