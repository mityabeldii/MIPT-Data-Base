INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(2,1)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(96,1)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(13,2)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(16,2)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(26,2)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(41,2)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(55,2)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(69,2)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(97,2)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(49,3)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(82,3)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(102,4)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(35,5)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(82,5)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(98,5)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(7,6)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(54,6)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(17,6)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(100,7)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(101,7)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(19,8)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(42,8)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(82,8)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(9,9)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(19,9)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(1,10)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(35,10)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(87,10)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(82,10)
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id])
     VALUES(57,10)
GO
