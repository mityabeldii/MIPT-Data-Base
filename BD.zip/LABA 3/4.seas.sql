INSERT INTO [dbo].[seas]([name])
     VALUES('Адриатическое море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Азовское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Аки')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Альборан')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Амундсена')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Андаманское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Аравийское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Арафурское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Балеарское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Бали')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Балтийское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Банда')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Баренцево море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Баффина')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Беллинсгаузена')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Белое море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Бенгальский залив')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Берингово море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Бискайский залив')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Бофорта')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Ванделя')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Ваттовое море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Висаян')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Внутреннее Японское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Восточно-Китайское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Восточно-Сибирское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Гебридское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Гренландское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Гудзонов залив')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Густава-Адольфа')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Дейвиса')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Дюрвиля')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Жёлтое море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Икарийское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Ионическое море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Ирландское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Ирмингера ')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Ицуки')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Камотес')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Карибское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Карское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Кельтское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Киликийское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Кипрское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Коралловое море ')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Коро50')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Короля Хокона VII')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Космонавтов')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Красное море ')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Критское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Кронпринца Густава')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Лабрадор ')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Лазарева')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Лаккадивское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Лаптевых')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Левантинское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Лигурийское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Линкольна ')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Мексиканский залив')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Минданао')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Миртойское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Молуккское море ')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Моусона')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Мраморное море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Новогвинейское (Бисмарка) море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Норвежское море ')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Охотское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Персидский залив')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Печорское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Рисер-Ларсена')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Росса')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Саву ')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Самар')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Саргассово море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Северное море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Серам')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Сибуян')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Скоша')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Содружества')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Соломоново море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Сомова')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Средиземное море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Сулавеси')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Сулу ')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Тасманово море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Тиморское море ')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Тирренское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Тувалу')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Уэдделла')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Фиджи ')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Филиппинское море ')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Флорес')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Фракийское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('море Хальмахера')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Харимское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Чёрное море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Чукотское море ')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Эгейское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Южно-Китайское море ')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Яванское море')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Японское (Восточное) море ')
GO
INSERT INTO [dbo].[seas]([name])
     VALUES('Сиамский залив')
GO