INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(468,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(246,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(104,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(186,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(422,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(272,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(74,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(431,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(12,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(249,40,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(467,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(77,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(436,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(245,7,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(291,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(287,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(203,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(351,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(214,45,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(489,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(228,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(154,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(304,23,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(140,44,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(170,32,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(413,18,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(248,21,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(256,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(421,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(452,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(269,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(74,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(386,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(402,36,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(440,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(423,27,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(467,23,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(164,42,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(297,43,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(460,9,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(305,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(407,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(453,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(106,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(212,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(360,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(239,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(345,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(105,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(362,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(169,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(95,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(437,36,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(487,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(142,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(228,42,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(57,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(350,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(147,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(409,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(246,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(90,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(244,35,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(259,45,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(295,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(20,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(9,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(198,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(103,27,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(402,42,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(4,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(369,35,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(461,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(479,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(494,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(181,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(126,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(84,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(381,35,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(349,9,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(247,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(235,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(235,45,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(340,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(218,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(222,47,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(421,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(218,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(274,23,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(315,18,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(66,40,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(406,32,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(377,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(452,46,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(261,35,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(265,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(360,46,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(475,49,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(475,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(188,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(57,27,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(236,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(229,7,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(164,47,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(316,5,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(103,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(193,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(298,35,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(130,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(105,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(178,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(167,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(394,9,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(135,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(458,6,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(154,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(179,40,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(232,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(290,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(356,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(103,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(91,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(50,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(308,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(225,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(196,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(255,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(454,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(444,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(262,16,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(351,11,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(342,44,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(22,11,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(225,35,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(368,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(324,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(249,42,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(166,46,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(71,18,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(134,7,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(71,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(335,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(303,9,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(369,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(338,40,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(358,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(208,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(208,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(451,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(454,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(218,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(491,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(243,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(304,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(231,42,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(79,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(484,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(450,16,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(214,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(449,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(433,49,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(238,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(208,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(143,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(195,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(211,27,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(233,33,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(9,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(379,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(422,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(327,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(144,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(299,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(373,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(415,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(260,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(54,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(368,49,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(135,46,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(500,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(361,21,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(349,45,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(486,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(313,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(254,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(76,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(266,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(45,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(290,11,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(352,18,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(267,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(156,7,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(70,44,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(120,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(442,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(346,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(160,42,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(69,27,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(237,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(482,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(24,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(378,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(63,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(471,36,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(102,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(132,5,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(5,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(266,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(328,21,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(352,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(304,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(106,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(230,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(428,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(426,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(47,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(346,16,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(329,45,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(31,16,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(268,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(181,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(199,46,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(324,42,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(499,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(292,16,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(70,36,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(118,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(15,47,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(410,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(191,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(184,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(141,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(363,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(116,35,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(36,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(194,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(153,43,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(441,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(278,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(469,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(128,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(421,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(497,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(443,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(368,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(73,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(411,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(61,49,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(32,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(462,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(365,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(243,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(78,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(356,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(215,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(33,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(207,7,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(296,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(334,7,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(205,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(45,21,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(483,45,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(214,16,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(11,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(180,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(294,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(113,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(304,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(271,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(232,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(390,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(96,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(98,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(340,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(63,5,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(450,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(348,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(241,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(424,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(410,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(323,49,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(40,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(352,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(444,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(32,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(78,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(128,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(422,16,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(130,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(87,44,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(94,9,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(412,9,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(437,21,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(116,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(247,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(394,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(259,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(187,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(247,49,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(64,9,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(397,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(340,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(494,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(487,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(67,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(169,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(50,33,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(102,43,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(93,43,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(82,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(413,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(95,49,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(159,11,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(442,23,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(112,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(375,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(306,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(468,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(259,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(325,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(215,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(36,27,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(26,44,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(40,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(435,11,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(492,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(228,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(69,47,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(20,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(132,11,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(9,47,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(20,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(494,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(427,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(263,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(148,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(184,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(197,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(191,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(76,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(261,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(67,18,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(33,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(131,33,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(261,11,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(198,33,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(466,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(249,32,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(436,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(52,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(94,5,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(132,23,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(227,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(188,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(477,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(391,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(257,36,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(462,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(272,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(432,43,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(73,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(245,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(264,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(216,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(323,40,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(495,43,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(121,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(413,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(181,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(189,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(383,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(247,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(442,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(106,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(353,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(85,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(480,40,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(68,47,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(337,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(34,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(433,18,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(70,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(399,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(231,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(176,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(498,47,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(435,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(255,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(187,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(136,32,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(265,18,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(346,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(200,23,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(232,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(418,43,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(98,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(465,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(264,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(92,6,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(439,24,0)
GO
