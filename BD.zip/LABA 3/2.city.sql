INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (1, 'Запорожье')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (1, 'Киев')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (1, 'Ялта')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (1, 'Алушта')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (1, 'Одесса')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (1, 'Севастополь')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (2, 'Москва')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (2, 'Санк-Петербург')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (2, 'Новгород')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (5, 'Афины')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (5, 'Кассандра')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (5, 'Родос')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (5, 'Крит')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (5, 'Греческие острова')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (5, 'Ираклион (Крит)')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (3, 'Каир')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (3, 'Шарм-эль-Шейх')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (3, 'Гиза')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (3, 'Луксор')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (3, 'Хургада')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (4, 'Бангкок')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (4, 'Пхукет')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (4, 'Паттайя')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (4, 'Самуи')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (6, 'Агра')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (6, 'Дели')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (6, 'Гоа')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (6, 'Керала')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (7, 'Токио')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (7, 'Иокогама')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (7, 'Киото')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (7, 'Осака')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (8, 'Париж')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (8, 'Версаль')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (8, 'Три долины')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (8, 'Шамони')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (9, 'Барселона')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (9, 'Мадрид')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (9, 'Андалусия')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (9, 'Тенерифе')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (10, 'Рим')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (10, 'Милан')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (10, 'Венеция')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (10, 'Флоренция')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (11, 'Бразилиа')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (11, 'Рио-де-Жанейро')
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (11, 'Салвадор')
GO
