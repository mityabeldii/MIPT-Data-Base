ALTER TABLE [resort] WITH CHECK ADD CONSTRAINT [resort_fk0] FOREIGN KEY ([country_id]) REFERENCES [country]([country_id])
ON UPDATE CASCADE
GO
ALTER TABLE [resort] CHECK CONSTRAINT [resort_fk0]
GO
ALTER TABLE [resort] WITH CHECK ADD CONSTRAINT [resort_fk1] FOREIGN KEY ([sea_id]) REFERENCES [seas]([sea_id])
ON UPDATE CASCADE
GO
ALTER TABLE [resort] CHECK CONSTRAINT [resort_fk1]
GO
ALTER TABLE [resort] WITH CHECK ADD CONSTRAINT [resort_fk2] FOREIGN KEY ([hotel_id]) REFERENCES [hotels]([hotel_id])
ON UPDATE CASCADE
GO
ALTER TABLE [resort] CHECK CONSTRAINT [resort_fk2]
GO

ALTER TABLE [offer] WITH CHECK ADD CONSTRAINT [offer_fk0] FOREIGN KEY ([resort_id]) REFERENCES [resort]([resort_id])
ON UPDATE CASCADE
GO
ALTER TABLE [offer] CHECK CONSTRAINT [offer_fk0]
GO
ALTER TABLE [offer] WITH CHECK ADD CONSTRAINT [offer_fk1] FOREIGN KEY ([client_id]) REFERENCES [client]([client_id])
ON UPDATE CASCADE
GO
ALTER TABLE [offer] CHECK CONSTRAINT [offer_fk1]
GO

ALTER TABLE [client] WITH CHECK ADD CONSTRAINT [client_fk0] FOREIGN KEY ([city_id]) REFERENCES [city]([city_id])
ON UPDATE CASCADE
GO
ALTER TABLE [client] CHECK CONSTRAINT [client_fk0]
GO


ALTER TABLE [city] WITH CHECK ADD CONSTRAINT [city_fk0] FOREIGN KEY ([country_id]) REFERENCES [country]([country_id])
ON UPDATE NO ACTION
GO
ALTER TABLE [city] CHECK CONSTRAINT [city_fk0]
GO


ALTER TABLE [hotels] WITH CHECK ADD CONSTRAINT [hotels_fk0] FOREIGN KEY ([city_id]) REFERENCES [city]([city_id])
ON UPDATE NO ACTION
GO
ALTER TABLE [hotels] CHECK CONSTRAINT [hotels_fk0]
GO

ALTER TABLE [accompanying] WITH CHECK ADD CONSTRAINT [accompanying_fk0] FOREIGN KEY ([offer_id]) REFERENCES [offer]([offer_id])
ON UPDATE CASCADE
GO
ALTER TABLE [accompanying] CHECK CONSTRAINT [accompanying_fk0]
GO
ALTER TABLE [accompanying] WITH CHECK ADD CONSTRAINT [accompanying_fk1] FOREIGN KEY ([client_id]) REFERENCES [client]([client_id])
ON UPDATE NO ACTION
GO
ALTER TABLE [accompanying] CHECK CONSTRAINT [accompanying_fk1]
GO

ALTER TABLE [seas_countries] WITH CHECK ADD CONSTRAINT [seas_countries_fk0] FOREIGN KEY ([sea_id]) REFERENCES [seas]([sea_id])
ON UPDATE CASCADE
GO
ALTER TABLE [seas_countries] CHECK CONSTRAINT [seas_countries_fk0]
GO
ALTER TABLE [seas_countries] WITH CHECK ADD CONSTRAINT [seas_countries_fk1] FOREIGN KEY ([country_id]) REFERENCES [country]([country_id])
ON UPDATE CASCADE
GO
ALTER TABLE [seas_countries] CHECK CONSTRAINT [seas_countries_fk1]
GO
