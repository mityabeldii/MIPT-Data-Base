CREATE TABLE [resort] (
	--Содержит опесание локации отдыха
	resort_id int IDENTITY(1,1), -- ID резорта, увеличивается на 1 при добавлении новой строки
	country_id int, 			 -- ID страны, в которой находится резорт
	place varchar(50), 			 -- наименования резорта
	feature varchar(50),		 -- особенность резорта
	sea_id int,					 -- ID моря, на берегу которого находится резорт, так же может принимать значение NULL, если резорт находится не на берегу моря
	hotel_id int,				 -- ID отеля, который находится на территории резорта
  CONSTRAINT [PK_RESORT] PRIMARY KEY CLUSTERED
  (
  [resort_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

) 
GO
CREATE TABLE [offer] (
	--Таблица со всеми данными по поездке
	offer_id int IDENTITY(1,1), -- ID путевки, увеличивается на 1 при добавлении новой строки
	resort_id int, 				-- ID резорта
	client_id int, 				-- ID клиента, на которого оформлен заказ
	price money, 				-- Цена путевки (R)
	discount real, 				-- скидка (0 <= discount <= 1) (0)
	start_date date, 			-- Дата начала поездки в формате '<ГОД>-<МЕСЯЦ>-<ДЕНЬ>' (R)(R)(R)
	end_date date,  			-- Дата окончания поездки в формате '<ГОД>-<МЕСЯЦ>-<ДЕНЬ>' (R)(R)(R)
  CONSTRAINT [PK_OFFER] PRIMARY KEY CLUSTERED
  (
  [offer_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

) 
GO
CREATE TABLE [client] (
	--Клиентская база
	client_id int IDENTITY(1,1), -- ID клиента, , увеличивается на 1 при добавлении новой строки
	first_name varchar(50),		 -- Фамилия (R)
	last_name varchar(50), 		 -- Имя (R)
	city_id int,				 -- ID города, в котором клиент проживает (R)
	phone_number varchar(50), 	 -- Телефонный номер клиента в формате '+<1> <234> <567-89-01>' по международному станжарту (R)(R)(R)
	email varchar(50),			 -- Электронная почта клиента в формате '<email>@<box>.<domen>'' (R)(R)(R)
	adress varchar(50),			 -- Адрес проживания клиента в формате 'ул.<Название> улицы д.<Номер дома>'' (R)(R)
	passport varchar(50),		 -- Паспортные данные в формате '<Номер>'' (R)
	foreign_passport varchar(50),-- Данные заграничного паспорта в формате '<Серия><Номер>'' (R)(R)
	birth_date date,			 -- Дата рождения клиента в формате '<ГОД>-<МЕСЯЦ>-<ДЕНЬ>' (R)(R)(R)
  CONSTRAINT [PK_CLIENT] PRIMARY KEY CLUSTERED
  (
  [client_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

) 
GO
CREATE TABLE [country] (
	country_id int IDENTITY(1,1),
	name varchar(50),
  CONSTRAINT [PK_COUNTRY] PRIMARY KEY CLUSTERED
  (
  [country_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

) 
GO
CREATE TABLE [city] (
	city_id int IDENTITY(1,1),
	country_id int,
	name varchar(50),
  CONSTRAINT [PK_CITY] PRIMARY KEY CLUSTERED
  (
  [city_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

) 
GO
CREATE TABLE [seas] (
	sea_id int IDENTITY(1,1),
	name varchar(50),
  CONSTRAINT [PK_SEAS] PRIMARY KEY CLUSTERED
  (
  [sea_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

) 
GO
CREATE TABLE [hotels] (
	hotel_id int IDENTITY(1,1),
	name varchar(50),
	city_id int,
	classifiacation real,
	web_site varchar(50),
  CONSTRAINT [PK_HOTELS] PRIMARY KEY CLUSTERED
  (
  [hotel_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

) 
GO
CREATE TABLE [accompanying] (
	offer_id int,
	client_id int,
	discount real
) 
GO
CREATE TABLE [seas_countries] (
	sea_id int,
	country_id int
) 
GO

ALTER TABLE [resort] WITH CHECK ADD CONSTRAINT [resort_fk1] FOREIGN KEY ([sea_id]) REFERENCES [seas]([sea_id])
ON UPDATE CASCADE
GO
ALTER TABLE [resort] CHECK CONSTRAINT [resort_fk1]
GO
ALTER TABLE [resort] WITH CHECK ADD CONSTRAINT [resort_fk2] FOREIGN KEY ([hotel_id]) REFERENCES [hotels]([hotel_id])
ON UPDATE CASCADE
GO
ALTER TABLE [resort] CHECK CONSTRAINT [resort_fk2]
GO

ALTER TABLE [offer] WITH CHECK ADD CONSTRAINT [offer_fk0] FOREIGN KEY ([resort_id]) REFERENCES [resort]([resort_id])
ON UPDATE CASCADE
GO
ALTER TABLE [offer] CHECK CONSTRAINT [offer_fk0]
GO
ALTER TABLE [offer] WITH CHECK ADD CONSTRAINT [offer_fk1] FOREIGN KEY ([client_id]) REFERENCES [client]([client_id])
ON UPDATE CASCADE
GO
ALTER TABLE [offer] CHECK CONSTRAINT [offer_fk1]
GO

ALTER TABLE [client] WITH CHECK ADD CONSTRAINT [client_fk0] FOREIGN KEY ([city_id]) REFERENCES [city]([city_id])
ON UPDATE CASCADE
GO
ALTER TABLE [client] CHECK CONSTRAINT [client_fk0]
GO


ALTER TABLE [city] WITH CHECK ADD CONSTRAINT [city_fk0] FOREIGN KEY ([country_id]) REFERENCES [country]([country_id])
ON UPDATE NO ACTION
GO
ALTER TABLE [city] CHECK CONSTRAINT [city_fk0]
GO


ALTER TABLE [hotels] WITH CHECK ADD CONSTRAINT [hotels_fk0] FOREIGN KEY ([city_id]) REFERENCES [city]([city_id])
ON UPDATE NO ACTION
GO
ALTER TABLE [hotels] CHECK CONSTRAINT [hotels_fk0]
GO

ALTER TABLE [accompanying] WITH CHECK ADD CONSTRAINT [accompanying_fk0] FOREIGN KEY ([offer_id]) REFERENCES [offer]([offer_id])
ON UPDATE CASCADE
GO
ALTER TABLE [accompanying] CHECK CONSTRAINT [accompanying_fk0]
GO
ALTER TABLE [accompanying] WITH CHECK ADD CONSTRAINT [accompanying_fk1] FOREIGN KEY ([client_id]) REFERENCES [client]([client_id])
ON UPDATE NO ACTION
GO
ALTER TABLE [accompanying] CHECK CONSTRAINT [accompanying_fk1]
GO

ALTER TABLE [seas_countries] WITH CHECK ADD CONSTRAINT [seas_countries_fk0] FOREIGN KEY ([sea_id]) REFERENCES [seas]([sea_id])
ON UPDATE CASCADE
GO
ALTER TABLE [seas_countries] CHECK CONSTRAINT [seas_countries_fk0]
GO
ALTER TABLE [seas_countries] WITH CHECK ADD CONSTRAINT [seas_countries_fk1] FOREIGN KEY ([country_id]) REFERENCES [country]([country_id])
ON UPDATE CASCADE
GO
ALTER TABLE [seas_countries] CHECK CONSTRAINT [seas_countries_fk1]
GO

INSERT INTO [dbo].[country] ([name]) VALUES ('Украина') 
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Россия') 
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Египет') 
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Таиланд') 
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Греция') 
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Индия') 
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Япония') 
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Франция') 
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Испания') 
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Италия') 
GO
INSERT INTO [dbo].[country] ([name]) VALUES ('Бразилия') 
GO

INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (1, 'Запорожье') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (1, 'Киев') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (1, 'Ялта') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (1, 'Алушта') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (1, 'Одесса') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (1, 'Севастополь') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (2, 'Москва') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (2, 'Санк-Петербург') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (2, 'Новгород') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (5, 'Афины') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (5, 'Кассандра') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (5, 'Родос') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (5, 'Крит') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (5, 'Греческие острова') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (5, 'Ираклион (Крит)') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (3, 'Каир') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (3, 'Шарм-эль-Шейх') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (3, 'Гиза') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (3, 'Луксор') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (3, 'Хургада') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (4, 'Бангкок') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (4, 'Пхукет') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (4, 'Паттайя') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (4, 'Самуи') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (6, 'Агра') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (6, 'Дели') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (6, 'Гоа') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (6, 'Керала') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (7, 'Токио') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (7, 'Иокогама') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (7, 'Киото') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (7, 'Осака') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (8, 'Париж') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (8, 'Версаль') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (8, 'Три долины') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (8, 'Шамони') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (9, 'Барселона') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (9, 'Мадрид') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (9, 'Андалусия') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (9, 'Тенерифе') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (10, 'Рим') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (10, 'Милан') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (10, 'Венеция') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (10, 'Флоренция') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (11, 'Бразилиа') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (11, 'Рио-де-Жанейро') 
GO
INSERT INTO [dbo].[city] ([country_id],[name]) VALUES (11, 'Салвадор') 
GO

INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Khortitsa Palace Hotel',1,89,'KhortitsaPalaceHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Inturist',1,78,'Inturist@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Отель Украина',2,75,'ОтельУкраина@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Арт-отель Баккара',2,81,'АртотельБаккара@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('ALFAVITO Kyiv Hotel',2,89,'ALFAVITOKyivHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Дворик у Причала',3,78,'ДворикуПричала@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Гостевой Дом Тавр',3,87,'ГостевойДомТавр@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Villa Bonne Maison with Garden',4,86,'VillaBonneMaisonwithGarden@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Riviera Sunrise Resort & SPA',4,86,'RivieraSunriseResortSPA@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Отель Фраполли',5,90,'ОтельФраполли@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Дюк Отель',5,92,'ДюкОтель@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Курортный комплекс Аквамарин',6,81,'КурортныйкомплексАквамарин@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Отель Песочная Бухта ',6,81,'ОтельПесочнаяБухта@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Космос',7,73,'Космос@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Отель Восход',7,77,'ОтельВосход@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Гостиница Измайлово Гамма',7,84,'ГостиницаИзмайловоГамма@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Гостиница Коринтия Санкт-Петербург',8,87,'ГостиницаКоринтияСанктПетербург@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Majestic Boutique Hotel Deluxe',8,92,'MajesticBoutiqueHotelDeluxe@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Отель Ibis Нижний Новгород',9,84,'ОтельIbisНижнийНовгород@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Отель Ibis Нижний Новгород',9,81,'ОтельIbisНижнийНовгород@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Royal Olympic Hotel',10,83,'RoyalOlympicHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Best Western My Athens Hotel',10,73,'BestWesternMyAthensHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Villa Madeleine',11,93,'VillaMadeleine@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Portes Beach Hotel',11,81,'PortesBeachHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Dionysos Hotel',12,87,'DionysosHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Villas Duc - Rhodes',12,89,'VillasDucRhodes@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Lyttos Beach',13,90,'LyttosBeach@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Kiani Beach Family Resort- All Inclusive',13,85,'KianiBeachFamilyResortAllInclusive@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Mykonos Blanc',14,92,'MykonosBlanc@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Aegean Land (ex Palace)',14,83,'AegeanLand@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Olive Green Hotel',15,95,'OliveGreenHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Lato Boutique Hotel',15,87,'LatoBoutiqueHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('GDM Megaron Hotel',15,94,'GDMMegaronHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Cecilia Hostel',16,86,'CeciliaHostel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Guardian Guest House',16,88,'GuardianGuestHouse@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Sharm El Sheikh Marriott Resort',17,72,'SharmElSheikhMarriottResort@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Sunrise Arabian Beach Resort',17,88,'SunriseArabianBeachResort@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Sunrise Arabian Beach Resort',18,85,'FourSeasonsCairoAtTheFirstResidence@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Best View Pyramids Hotel',18,87,'BestViewPyramidsHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Maritim Jolie Ville Kings Island',19,92,'MaritimJolieVilleKingsIsland@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Achti Resort',19,83,'AchtiResort@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hurghada Dreams Hotel Apartment',20,77,'HurghadaDreamsHotelApartment@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Baiyoke Sky Hotel',21,74,'BaiyokeSkyHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Chatrium Hotel Riverside Bangkok',21,90,'ChatriumHotelRiversideBangkok@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Eastin Grand Hotel Sathorn',21,93,'EastinGrandHotelSathorn@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('The Memory at On On Hotel',22,86,'TheMemoryatOnOnHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Casa Blanca Boutique Hotel',22,90,'CasaBlancaBoutiqueHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Meroom',22,90,'Meroom@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Amari Ocean Pattaya',23,85,'AmariOceanPattaya@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Royal Cliff Grand Hotel',23,87,'RoyalCliffGrandHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Santiburi Beach Resort & Spa',24,93,'SantiburiBeachResortSpa@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Sensimar Koh Samui – Adults Only Resort',24,96,'SensimarKohSamui–AdultsOnlyResort@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Banyan Tree Samui',24,92,'BanyanTreeSamui@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Seven Hills Tower',25,88,'SevenHillsTower@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('ITC Mughal A Luxury Collection Hotel Agra',25,84,'ITCMughalALuxuryCollectionHotelAgra@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hotel City Star',26,86,'HotelCityStar@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('The Prime Balaji Deluxe',26,81,'ThePrimeBalajiDeluxe@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])  VALUES('The Leela Goa',27,90,'TheLeelaGoa@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Vi vanta by Taj Holiday Village',27,85,'Vi vantabyTajHolidayVillage@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Purity',28,92,'Purity@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Kochi Marriott Hotel',28,91,'KochiMarriottHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Carnoustie Ayurveda & Wellness Resort',28,86,'CarnoustieAyurvedaWellnessResort@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Grand Nikko Tokyo Daiba',29,91,'GrandNikkoTokyoDaiba@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Royal Park Hotel The Shiodome',29,89,'RoyalParkHotelTheShiodome@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Mitsui Garden Hotel Ginza Premier',29,88,'MitsuiGardenHotelGinzaPremier@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hotel Edit Yokohama',30,87,'HotelEditYokohama@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Daiwa Roynet Hotel Yokohama-Koen',30,86,'DaiwaRoynetHotelYokohamaKoen@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hotel Gran Ms Kyoto',31,85,'HotelGranMsKyoto@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('HOTEL MYSTAYS Kyoto Shijo',31,84,'HOTELMYSTAYSKyotoShijo@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Piece Hostel Sanjo',31,93,'PieceHostelSanjo@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('HOTEL MYSTAYS Sakaisuji Honmachi',32,79,'HOTELMYSTAYSSakaisujiHonmachi@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Daiwa Roynet Hotel Osaka-Kitahama',32,88,'DaiwaRoynetHotelOsakaKitahama@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Mitsui Garden Hotel Osaka Premier',32,88,'MitsuiGardenHotelOsakaPremier@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Warwick Paris (Former Warwick Champs-Elysees)',33,8.1,'WarwickPars@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Pullman Paris Montparnasse',33,83,'PullmanParisMontparnasse@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hôtel California Champs Elysées',33,81,'HôtelCaliforniaChampsElysées@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])  VALUES('Golden Tulip Bercy Gare de Lyon 209',33,83,'GoldenTulipBercyGaredeLyon209@mymail.com')
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hotel Du Louvre, a Hyatt Hotel',33,83,'HotelDuLouve@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Appartements - Le Logis Versaillais',34,95,'AppartementsLeLogisVersaillais@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hôtel du Jeu de Paume',34,88,'HôtelduJeudePaume@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hôtel Fitz Roy',35,87,'HôtelFitzRoy@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hôtel Alpen Ruitor',35,90,'HôtelAlpenRuitor@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hôtel L_Heliopic Sweet and Spa',36,9.1,'HôteLHeliopicSweetandSpa@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Chalet Hôtel Le Prieuré',36,86,'ChaletHôtelLePrieuré@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Boutique Hotel Le Morgane',36,89,'BoutiqueHotelLeMorgane@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hôtel Mont-Blanc Chamonix',36,93,'HôtelMontBlancChamonix@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Eurostars Grand Marina Hotel GL',37,86,'EurostarsGrandMarinaHotelGL@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Catalonia Sagrada Familia',37,81,'CataloniaSagradaFamilia@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Royal Passeig de Gracia',37,86,'RoyalPasseigdeGracia@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Majestic Hotel & Spa Barcelona GL',37,90,'MajesticHotelSpaBarcelonaGL@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Toc Hostel Madrid',38,90,'TocHostelMadrid@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hotel Liabeny',38,89,'HotelLiabeny@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Preciados',38,90,'Preciados@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Melia Sierra Ne vada',39,83,'MeliaSierraNe vada@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Gran Meliá Don Pepe',39,83,'GranMeliáDonPepe@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Inside Plaza Sierra Ne vada',39,84,'InsidePlazaSierraNe vada@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Adrián Hoteles Jardines de Ni varia',40,90,'AdriánHotelesJardinesdeNi varia@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hotel Suite Villa María',40,91,'HotelSuiteVillaMaría@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('H10 Costa Adeje Palace',40,82,'H10CostaAdejePalace@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Iberostar Las Dalias - All Inclusive',40,84,'IberostarLasDaliasAllInclusive@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Iberostar Grand Hotel El Mirador - Adults Only',40,93,'IberostarGrandHotelElMiradorAdultsOnly@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Welcome Piram Hotel',41,81,'WelcomePiramHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hotel Quirinale',41,83,'HotelQuirinale@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hotel Nord Nuo va Roma',41,83,'HotelNordNuo vaRoma@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('NH Collection Milano President',42,87,'NHCollectionMilanoPresident@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hotel Da Vinci',42,80,'HotelDaVinci@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Rosa Grand Milano - Starhotels Collezione',42,86,'RosaGrandMilanoStarhotelsCollezione@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('The Square Milano Duomo',42,89,'TheSquareMilanoDuomo@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hotel Ala',43,86,'HotelAla@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hotel Bonvecchiati',43,82,'HotelBonvecchiati@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Pesaro Palace',43,87,'PesaroPalace@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hotel Belle Epoque',43,77,'HotelBelleEpoque@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hilton Molino Stucky Venice',43,82,'HiltonMolinoStuckyVenice@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Plus Florence',44,83,'PlusFlorence@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Wow Florence Hostel',44,84,'WowFlorenceHostel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hostel Archi Rossi',44,85,'HostelArchiRossi@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('FH Hotel Calzaiuoli',44,87,'FHHotelCalzaiuoli@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('B&B Le Stanze del Duomo',44,91,'BBLeStanzedelDuomo@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Meliá Brasil 21',45,86,'MeliáBrasil21@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Windsor Brasília Hotel',45,94,'WindsorBrasíliaHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Athos Bulcão Hplus Executive',45,88,'AthosBulcãoHplusExecutive@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Manhattan Plaza',45,87,'ManhattanPlaza@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Américas Copacabana Hotel',46,87,'AméricasCopacabanaHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site])  VALUES('Golden Tulip Rio Copacabana',46,81,'GoldenTulipRioCopacabana@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Royal Rio Palace Hotel',46,80,'RoyalRioPalaceHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Tulip Inn Rio Copacabana',46,81,'TulipInnRioCopacabana@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Bahiacafé Hotel',47,88,'BahiacaféHotel@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Pousada do Boqueirão',47,92,'PousadadoBoqueirão@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Pousada Solar dos Deuses',47,96,'PousadaSolardosDeuses@mymail.com') 
GO
INSERT INTO [dbo].[hotels]([name],[city_id],[classifiacation],[web_site]) VALUES('Hotel Casa do Amarelindo',47,93,'HotelCasadoAmarelindo@mymail.com') 
GO

INSERT INTO [dbo].[seas]([name]) VALUES('Адриатическое море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Азовское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Аки') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Альборан') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Амундсена') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Андаманское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Аравийское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Арафурское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Балеарское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Бали') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Балтийское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Банда') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Баренцево море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Баффина') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Беллинсгаузена') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Белое море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Бенгальский залив') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Берингово море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Бискайский залив') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Бофорта') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Ванделя') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Ваттовое море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Висаян') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Внутреннее Японское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Восточно-Китайское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Восточно-Сибирское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Гебридское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Гренландское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Гудзонов залив') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Густава-Адольфа') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Дейвиса') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Дюрвиля') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Жёлтое море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Икарийское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Ионическое море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Ирландское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Ирмингера ') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Ицуки') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Камотес') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Карибское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Карское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Кельтское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Киликийское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Кипрское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Коралловое море ') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Коро50') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Короля Хокона VII') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Космонавтов') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Красное море ') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Критское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Кронпринца Густава') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Лабрадор ') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Лазарева') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Лаккадивское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Лаптевых') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Левантинское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Лигурийское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Линкольна ') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Мексиканский залив') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Минданао') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Миртойское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Молуккское море ') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Моусона') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Мраморное море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Новогвинейское (Бисмарка) море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Норвежское море ') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Охотское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Персидский залив') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Печорское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Рисер-Ларсена') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Росса') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Саву ') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Самар') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Саргассово море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Северное море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Серам') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Сибуян') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Скоша') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Содружества') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Соломоново море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Сомова') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Средиземное море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Сулавеси') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Сулу ') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Тасманово море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Тиморское море ') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Тирренское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Тувалу') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Уэдделла') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Фиджи ') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Филиппинское море ') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Флорес') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Фракийское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('море Хальмахера') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Харимское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Чёрное море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Чукотское море ') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Эгейское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Южно-Китайское море ') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Яванское море') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Японское (Восточное) море ') 
GO
INSERT INTO [dbo].[seas]([name]) VALUES('Сиамский залив') 
GO

INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(1,'place','feature',96,6) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(1,'place','feature',96,7) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(1,'place','feature',96,8) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(1,'place','feature',96,9) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(1,'place','feature',96,10) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(1,'place','feature',96,11) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(1,'place','feature',96,12) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(1,'place','feature',96,13) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',49,33) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',49,34) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',82,33) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',82,34) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',49,35) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',49,36) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',82,35) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',82,36) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',49,37) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',49,38) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',82,37) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',82,38) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',49,39) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',49,40) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',82,39) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',82,40) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',49,41) 
GO
INSERT INTO [dbo].[resort]([country_id],[place],[feature],[sea_id],[hotel_id]) VALUES(3,'place','feature',82,41) 
GO

INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Ильин', 'Ваган', 7 ,'+7 991 167-99-82', 'iliin@mymail.com', 'ул.Амосова д.38', '786842', 'AB786842', '1951/5/26') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Баранова', 'Афина', 10,' +7 974 111-87-27', 'barano va@mymail.com', 'ул.Амосова д.41', '487504', 'AB487504', '1978/12/1') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Соловьёва', 'Каролина', 9 ,'+7 937 915-17-21', 'solovie va@mymail.com', 'ул.Амосова д.48', '329275', 'AB329275', '1998/9/20') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Савельев', 'Аскар', 8 ,'+7 929 958-72-44', 'saveliev@mymail.com', 'ул.Амосова д.47', '946477', 'AB946477', '2003/9/6') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Александров', 'Виталий', 4 ,'+7 919 821-93-57', 'alexandrov@mymail.com', 'ул.Амосова д.63', '388296', 'AB388296', '1993/1/18') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Соловьёва', 'Софья', 4 ,'+7 911 763-42-66', 'solovie va_sophie@mymail.com', 'ул.Амосова д.58', '824492', 'AB824492', '2009/6/6') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Новиков', 'Давлат', 4 ,'+7 998 941-15-22', 'novikOFF@mymail.com', 'ул.Амосова д.68', '494557', 'AB494557', '2004/5/4') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Смирнова', 'Ангелина', 7 ,'+7 997 675-57-82', 'smir_angel@mymail.com', 'ул.Амосова д.35', '722416', 'AB722416', '1990/7/30') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Максимов', 'Егор', 3 ,'+7 921 277-33-99', 'maximov@mymail.com', 'ул.Соловьёваа д.50', '789216', 'AB789216', '1979/11/22') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Денисов', 'Владислав', 3 ,'+7 978 778-35-97', 'denisov@mymail.com', 'ул.Амосова д.71', '913942', 'AB913942', '1971/2/5') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Коновалов', 'Артур', 11,' +7 966 394-13-99', 'danilov_artur@mymail.com', 'ул.Смирноваа д.61', '959683', 'AB959683', '1980/11/7') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Данилов', 'Виталий', 2 ,'+7 919 335-14-18', 'danilov_vitalka@mymail.com', 'ул.Амосова д.41', '6446', 'AB6446', '1993/4/27') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Титова', 'Вероника', 7 ,'+7 961 475-86-21', 'tito va@mymail.com', 'ул.Денисова д.46', '794991', 'AB794991', '1991/9/24') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Волкова', 'Олеся', 1 ,'+7 992 584-87-52', 'volko va@mymail.com', 'ул.Амосова д.68', '84215', 'AB84215', '1989/9/9') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Алексеева', 'Александра', 11,' +7 929 218-21-44', 'alexee va@mymail.com', 'ул.Данилова д.53', '557609', 'AB557609', '1982/10/25') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Осипова', 'Эльвира', 5 ,'+7 972 819-35-27', 'osipo va@mymail.com', 'ул.Амосова д.41', '972035', 'AB972035', '1969/3/9') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Щербаков', 'Мстислав', 10,' +7 998 648-91-39', 'scherbako va@mymail.com', 'ул.Амосова д.66', '261723', 'AB261723', '1995/11/25') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Карпова', 'Аделия', 5 ,'+7 922 647-76-41', 'karpo va@mymail.com', 'ул.Амосова д.52', '366482', 'AB366482', '2006/9/10') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Миллер', 'Давид', 3 ,'+7 944 389-58-29', 'miller@mymail.com', 'ул.Денисова д.47', '701472', 'AB701472', '1980/6/18') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Быков', 'Виталий', 1 ,'+7 987 954-62-25', 'bikov@mymail.com', 'ул.Амосова д.55', '474916', 'AB474916', '1950/6/3') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Михайлова', 'Татьяна', 4 ,'+7 912 649-49-49', 'mikhailo va@mymail.com', 'ул.Карповаа д.42', '128869', 'AB128869', '1968/3/29') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Прокофьев', 'Никита', 11,' +7 992 698-49-81', 'prokofiev@mymail.com', 'ул.Волковаа д.62', '351489', 'AB351489', '1973/4/25') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Гусев', 'Радислав', 5 ,'+7 932 865-46-44', 'gusev@mymail.com', 'ул.Денисова д.76', '224125', 'AB224125', '1954/2/20') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Сорокина', 'Динара', 6 ,'+7 987 162-12-77', 'sorokina@mymail.com', 'ул.Титоваа д.69', '794312', 'AB794312', '1954/10/29') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Трофимов', 'Анатолий', 5 ,'+7 983 912-99-15', 'trophimov@mymail.com', 'ул.Амосова д.55', '506992', 'AB506992', '2001/2/12') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Матвеев', 'Ваган', 1 ,'+7 968 921-36-87', 'matveev_ vagan@mymail.com', 'ул.Амосова д.43', '54108', 'AB54108', '1952/5/18') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Фомина', 'Елена', 4 ,'+7 969 836-36-52', 'fomina@mymail.com', 'ул.Волковаа д.79', '325554', 'AB325554', '1999/10/12') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Воробьёв', 'Кирилл', 3 ,'+7 929 859-46-48', 'vorobievK@mymail.com', 'ул.Прокофьева д.36', '968498', 'AB968498', '1992/2/27') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Данилов', 'Виталий', 3 ,'+7 926 516-64-22', 'danilov_vit@mymail.com', 'ул.Прокофьева д.35', '937846', 'AB937846', '1998/10/26') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Никитина', 'Инна', 8 ,'+7 988 625-81-31', 'nikitina@mymail.com', 'ул.Амосова д.36', '554830', 'AB554830', '1964/8/16') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Полякова', 'Элина', 7 ,'+7 945 996-47-66', 'polyako va_all@mymail.com', 'ул.Данилова д.42', '656299', 'AB656299', '1967/8/21') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Борисов', 'Анатолий', 8 ,'+7 969 729-38-76', 'borisov@mymail.com', 'ул.Амосова д.47', '688460', 'AB688460', '1961/11/9') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Титов', 'Олесь', 7 ,'+7 951 782-35-69', 'titov@mymail.com', 'ул.Соловьёваа д.62', '913464', 'AB913464', '1979/3/23') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Кузьмина', 'Эльвира', 3 ,'+7 974 161-15-44', 'kuzmina_alya@mymail.com', 'ул.Данилова д.57', '10448', 'AB10448', '1980/5/14') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Кириллова', 'Аида', 3 ,'+7 924 155-91-39', 'kirilo va@mymail.com', 'ул.Михайловаа д.39', '926236', 'AB926236', '1965/8/21') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Михайлов', 'Малик', 4 ,'+7 967 724-71-46', 'mikhailov@mymail.com', 'ул.Савельева д.44', '186652', 'AB186652', '1952/10/16') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Данилова', 'Екатерина', 3 ,'+7 968 186-19-51', 'danilo va@mymail.com', 'ул.Амосова д.69', '860538', 'AB860538', '1966/2/16') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Яковлева', 'Юлиана', 9 ,'+7 913 923-87-91', 'yakovle va@mymail.com', 'ул.Поляковаа д.30', '311275', 'AB311275', '1964/3/6') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Титова', 'Сати', 3 ,'+7 953 723-49-84', 'tito va_sati@mymail.com', 'ул.Прокофьева д.44', '145674', 'AB145674', '1956/3/16') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Голубева', 'Маргарита', 8 ,'+7 976 468-33-72', 'golube va_m@mymail.com', 'ул.Александрова д.70', '303004', 'AB303004', '2007/12/4') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Дмитриева', 'Наталья', 10,' +7 951 897-81-45', 'dmitrie va@mymail.com', 'ул.Новикова д.51', '978015', 'AB978015', '1994/11/5') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Герасимова', 'Айжан', 1 ,'+7 943 869-65-73', 'gerasimo va@mymail.com', 'ул.Денисова д.30', '924217', 'AB924217', '2006/4/15') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Титова', 'Анна', 6 ,'+7 962 638-89-82', 'tito va_ann@mymail.com', 'ул.Дмитриеваа д.48', '319474', 'AB319474', '1977/2/15') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Троицкийа', 'Куралай', 4 ,'+7 956 984-62-63', 'troitskaya@mymail.com', 'ул.Трофимова д.59', '467460', 'AB467460', '1988/3/28') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Абрамов', 'Вадим', 8 ,'+7 945 388-49-67', 'abramov@mymail.com', 'ул.Амосова д.77', '235695', 'AB235695', '1973/6/7') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Лебедева', 'Дарига', 1 ,'+7 949 484-57-38', 'lebede va@mymail.com', 'ул.Савельева д.39', '25244', 'AB25244', '1954/9/5') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Мартынова', 'Куралай', 3 ,'+7 959 297-92-81', 'martyno va@mymail.com', 'ул.Волковаа д.63', '590277', 'AB590277', '1961/8/18') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Сидорова', 'Салтанат', 10,' +7 999 467-99-17', 'sidoro va@mymail.com', 'ул.Амосова д.47', '315825', 'AB315825', '1986/5/15') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Карпова', 'Ярослава', 4 ,'+7 939 489-92-24', 'karpo va@mymail.com', 'ул.Яковлеваа д.42', '626570', 'AB626570', '2007/4/6') 
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date]) VALUES('Дмитриева', 'Гульназ', 9 ,'+7 927 654-92-34', 'dmitrie va@mymail.com', 'ул.Борисова д.62', '94671', 'AB94671', '1993/4/8') 
GO

INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,39,8900,0.0,'2015/10/9','2015/12/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,42,2200,0.0,'2012/8/17','2012/11/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,30,4400,0.0,'2015/3/1','2015/5/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,48,7400,0.0,'2013/1/11','2013/3/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,15,6600,0.0,'2011/5/12','2011/7/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,28,5900,0.0,'2016/10/19','2016/1/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,23,9600,0.0,'2015/1/1','2015/3/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,13,8100,0.0,'2012/2/7','2012/5/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,3,9900,0.0,'2016/6/22','2016/9/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,18,4100,0.0,'2014/6/5','2014/8/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,22,7600,0.0,'2012/10/14','2012/12/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,7,8300,0.0,'2015/9/6','2015/11/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,39,4600,0.0,'2014/12/15','2014/1/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,26,400,0.0,'2015/8/11','2015/11/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,33,6500,0.0,'2012/12/21','2013/2/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,1,8800,0.0,'2014/10/8','2014/12/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,38,7200,0.0,'2015/7/24','2015/8/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,12,7500,0.0,'2011/12/6','2012/2/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,8,4100,0.0,'2014/12/17','2015/2/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,12,400,0.0,'2011/11/13','2011/1/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,20,7500,0.0,'2013/1/3','2013/3/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,4,7200,0.0,'2016/2/14','2016/3/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,12,6300,0.0,'2012/8/28','2012/11/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,29,5500,0.0,'2012/7/10','2012/9/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,38,200,0.0,'2012/5/22','2012/8/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,20,800,0.0,'2014/12/25','2015/2/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,2,1000,0.0,'2016/3/23','2016/6/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,43,5400,0.0,'2011/4/19','2011/6/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,2,1700,0.0,'2016/8/11','2016/10/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,39,4500,0.0,'2013/2/6','2013/5/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,35,400,0.0,'2015/7/27','2015/10/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,18,8800,0.0,'2014/6/6','2014/8/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,20,2400,0.0,'2012/12/13','2013/2/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,36,8700,0.0,'2013/11/18','2014/2/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,31,4700,0.0,'2012/4/26','2012/7/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(13,41,3800,0.0,'2016/4/7','2016/7/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(13,40,8100,0.0,'2016/12/14','2017/3/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,24,300,0.0,'2015/4/26','2015/7/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,16,1800,0.0,'2012/12/6','2013/3/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,37,7100,0.0,'2013/5/7','2013/6/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,7,900,0.0,'2014/8/3','2014/11/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,20,300,0.0,'2016/8/21','2016/10/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,22,3500,0.0,'2013/8/16','2013/11/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,31,7200,0.0,'2015/9/25','2015/10/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(12,16,2000,0.0,'2011/2/5','2011/5/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,30,1800,0.0,'2013/3/7','2013/6/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,48,2600,0.0,'2011/1/3','2011/3/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,43,2400,0.0,'2011/6/16','2011/8/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,8,5100,0.0,'2015/11/13','2015/1/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,15,5200,0.0,'2012/12/26','2013/2/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,6,5100,0.0,'2012/2/20','2012/4/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,23,1700,0.0,'2012/9/7','2012/12/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,12,5800,0.0,'2012/3/18','2012/5/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,32,900,0.0,'2011/11/9','2012/2/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,43,9100,0.0,'2013/5/16','2013/7/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,47,9600,0.0,'2012/12/2','2013/3/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,25,1900,0.0,'2012/10/21','2012/1/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,3,3200,0.0,'2016/11/7','2016/1/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,32,5500,0.0,'2011/8/2','2011/10/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,35,4500,0.0,'2011/11/6','2011/12/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,1,4600,0.0,'2016/7/21','2016/9/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,14,4100,0.0,'2012/10/15','2012/1/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,12,8400,0.0,'2011/11/11','2011/1/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,43,9600,0.0,'2016/9/25','2016/12/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,32,8400,0.0,'2015/2/10','2015/4/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,24,7200,0.0,'2013/6/18','2013/8/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,36,8000,0.0,'2014/11/23','2014/12/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,40,6700,0.0,'2012/12/18','2013/2/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,37,4200,0.0,'2011/2/7','2011/5/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,12,8500,0.0,'2013/10/6','2013/12/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(13,24,4200,0.0,'2012/8/4','2012/10/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,17,4900,0.0,'2016/9/10','2016/11/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,10,8500,0.0,'2011/12/17','2012/2/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,6,1800,0.0,'2012/12/23','2013/2/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,12,6300,0.0,'2014/2/10','2014/4/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,3,7800,0.0,'2016/3/9','2016/5/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,41,5400,0.0,'2011/6/4','2011/9/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,23,1800,0.0,'2016/12/23','2017/2/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,36,2100,0.0,'2012/3/13','2012/4/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,6,4600,0.0,'2014/11/8','2015/2/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,20,4600,0.0,'2012/6/5','2012/9/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(13,37,8700,0.0,'2014/7/11','2014/10/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,1,6700,0.0,'2012/11/6','2012/1/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,13,200,0.0,'2015/12/15','2015/1/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,4,8700,0.0,'2012/7/3','2012/9/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,28,1200,0.0,'2015/8/28','2015/11/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,40,9800,0.0,'2015/4/16','2015/5/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,5,9600,0.0,'2016/6/18','2016/8/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,48,3500,0.0,'2015/8/5','2015/10/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,11,5700,0.0,'2011/10/12','2011/12/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,44,1000,0.0,'2013/5/1','2013/8/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,12,3600,0.0,'2012/10/9','2012/11/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,43,4600,0.0,'2015/2/7','2015/4/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,31,3200,0.0,'2011/10/1','2011/12/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,48,5600,0.0,'2014/2/2','2014/4/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,37,9100,0.0,'2014/7/18','2014/8/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,12,100,0.0,'2012/2/12','2012/5/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,39,300,0.0,'2016/9/2','2016/11/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,35,1900,0.0,'2014/12/1','2015/2/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,39,9200,0.0,'2014/8/18','2014/11/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,5,800,0.0,'2013/5/15','2013/7/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,21,8400,0.0,'2011/8/6','2011/11/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,39,1900,0.0,'2011/9/12','2011/11/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,45,6600,0.0,'2013/8/11','2013/10/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,46,6000,0.0,'2013/12/22','2013/1/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,28,8400,0.0,'2014/3/2','2014/6/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,39,9200,0.0,'2012/2/18','2012/3/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,23,7200,0.0,'2013/3/4','2013/6/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,22,3500,0.0,'2014/8/17','2014/10/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,5,4700,0.0,'2013/11/14','2013/1/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,20,5800,0.0,'2014/6/28','2014/7/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,24,2200,0.0,'2014/12/21','2015/3/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,43,2600,0.0,'2016/3/24','2016/6/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,10,2100,0.0,'2012/7/7','2012/10/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,33,9100,0.0,'2014/7/18','2014/8/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,42,600,0.0,'2012/4/21','2012/7/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,45,8200,0.0,'2013/6/11','2013/8/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,47,9400,0.0,'2013/12/9','2014/2/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,16,9700,0.0,'2014/4/21','2014/7/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,27,6100,0.0,'2012/6/28','2012/9/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,10,8300,0.0,'2015/5/22','2015/7/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,19,9300,0.0,'2016/11/5','2017/2/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,30,5500,0.0,'2015/12/1','2016/2/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,12,3200,0.0,'2013/9/12','2013/10/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,33,3400,0.0,'2014/8/9','2014/11/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(13,10,1900,0.0,'2016/4/26','2016/6/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,4,2100,0.0,'2016/8/26','2016/10/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,14,4700,0.0,'2012/7/21','2012/10/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,32,6900,0.0,'2014/8/25','2014/10/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,14,7900,0.0,'2015/6/4','2015/9/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,32,7000,0.0,'2015/11/7','2015/1/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,50,5500,0.0,'2013/11/17','2014/2/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,5,9700,0.0,'2011/9/9','2011/12/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,30,4400,0.0,'2014/8/3','2014/10/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,35,9200,0.0,'2013/7/7','2013/8/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,20,2700,0.0,'2012/2/1','2012/4/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,45,5500,0.0,'2011/2/7','2011/5/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,28,1400,0.0,'2016/8/14','2016/10/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,16,6900,0.0,'2016/4/15','2016/6/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(13,21,3800,0.0,'2016/4/12','2016/6/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,1,2100,0.0,'2015/3/22','2015/4/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,29,400,0.0,'2012/4/4','2012/6/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,7,2500,0.0,'2011/10/2','2011/12/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,10,5200,0.0,'2016/3/3','2016/6/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,5,3300,0.0,'2014/3/2','2014/6/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,6,3800,0.0,'2015/6/16','2015/8/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,2,7600,0.0,'2013/9/7','2013/12/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,17,1300,0.0,'2013/8/5','2013/11/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,8,5400,0.0,'2014/4/15','2014/6/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,15,1300,0.0,'2013/11/20','2013/1/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,19,1000,0.0,'2013/1/14','2013/4/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,18,3700,0.0,'2013/3/24','2013/4/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(12,10,3200,0.0,'2016/8/10','2016/10/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(12,2,7800,0.0,'2012/5/18','2012/7/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,9,200,0.0,'2016/8/11','2016/9/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,49,7800,0.0,'2015/6/5','2015/8/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,15,1000,0.0,'2012/5/1','2012/8/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,39,5300,0.0,'2013/10/23','2013/1/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,4,1500,0.0,'2015/11/28','2016/2/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,48,2600,0.0,'2012/4/28','2012/5/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,12,3700,0.0,'2012/9/21','2012/10/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(12,47,5300,0.0,'2014/7/4','2014/9/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,43,4600,0.0,'2016/11/2','2016/1/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,16,7300,0.0,'2012/5/19','2012/6/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,17,6600,0.0,'2011/12/20','2012/3/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,6,100,0.0,'2014/8/28','2014/11/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(12,13,8900,0.0,'2015/5/17','2015/7/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(18,43,7900,0.0,'2012/9/22','2012/11/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,1,6400,0.0,'2016/6/7','2016/8/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,23,2600,0.0,'2016/2/5','2016/5/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,3,3900,0.0,'2012/6/12','2012/9/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(13,39,3000,0.0,'2016/7/8','2016/10/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,49,6100,0.0,'2015/4/4','2015/6/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(18,3,9400,0.0,'2014/12/24','2015/2/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,40,8900,0.0,'2011/8/12','2011/10/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(18,22,3700,0.0,'2013/11/9','2014/2/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,48,4400,0.0,'2015/6/10','2015/8/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,19,7000,0.0,'2012/11/13','2013/2/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,31,8900,0.0,'2015/9/28','2015/10/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,11,6200,0.0,'2016/8/16','2016/10/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(13,25,4800,0.0,'2011/12/18','2012/2/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(13,48,700,0.0,'2011/3/3','2011/5/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,32,6700,0.0,'2013/4/22','2013/6/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(18,5,9300,0.0,'2013/1/1','2013/4/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,38,7700,0.0,'2013/9/21','2013/10/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,12,2600,0.0,'2015/2/14','2015/3/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,34,3600,0.0,'2012/3/26','2012/6/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,1,4400,0.0,'2015/5/16','2015/7/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,9,6000,0.0,'2012/6/27','2012/7/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,21,6800,0.0,'2015/12/14','2016/2/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,49,9700,0.0,'2014/1/14','2014/3/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,1,9800,0.0,'2011/7/16','2011/9/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,39,8600,0.0,'2014/5/27','2014/6/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,29,4000,0.0,'2015/3/3','2015/6/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,28,8800,0.0,'2015/9/10','2015/11/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,12,9000,0.0,'2012/10/2','2012/1/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,43,2200,0.0,'2014/3/8','2014/5/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,21,8200,0.0,'2016/1/2','2016/3/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,45,3400,0.0,'2013/7/12','2013/9/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,1,700,0.0,'2012/10/27','2012/1/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,45,5000,0.0,'2012/7/19','2012/9/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,36,3300,0.0,'2013/5/26','2013/6/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,17,300,0.0,'2011/3/28','2011/5/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,35,5600,0.0,'2012/1/24','2012/3/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,1,4900,0.0,'2011/3/11','2011/4/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,38,7300,0.0,'2012/11/6','2013/2/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,25,9500,0.0,'2016/1/26','2016/2/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,10,7400,0.0,'2016/11/25','2016/1/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,46,1700,0.0,'2016/2/3','2016/5/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,29,6000,0.0,'2014/11/27','2015/2/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,38,400,0.0,'2011/4/15','2011/6/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,29,1400,0.0,'2011/2/1','2011/4/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,49,2500,0.0,'2013/5/15','2013/8/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(12,9,6400,0.0,'2015/4/10','2015/6/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,1,4500,0.0,'2011/10/21','2011/11/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,21,7500,0.0,'2014/7/19','2014/8/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,49,2900,0.0,'2012/5/11','2012/7/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,23,8100,0.0,'2015/1/18','2015/3/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,7,800,0.0,'2013/7/21','2013/8/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,39,9800,0.0,'2015/7/3','2015/9/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,48,100,0.0,'2014/10/25','2014/1/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,45,7700,0.0,'2012/4/6','2012/6/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,50,8900,0.0,'2013/4/7','2013/7/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,3,1300,0.0,'2013/3/27','2013/4/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,28,5500,0.0,'2013/4/27','2013/5/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,5,4000,0.0,'2012/5/27','2012/7/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,50,7300,0.0,'2013/6/21','2013/9/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,13,1200,0.0,'2014/3/24','2014/5/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,43,500,0.0,'2016/11/27','2016/12/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,22,5700,0.0,'2014/1/22','2014/2/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,38,4200,0.0,'2013/9/25','2013/12/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,48,400,0.0,'2016/9/22','2016/11/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,13,6800,0.0,'2014/9/13','2014/12/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,31,9500,0.0,'2014/10/20','2014/1/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,45,3500,0.0,'2012/9/12','2012/11/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,10,7200,0.0,'2011/9/14','2011/12/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,2,1200,0.0,'2014/12/6','2015/3/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,13,9100,0.0,'2013/5/11','2013/7/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(12,41,2400,0.0,'2013/7/11','2013/9/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,2,9100,0.0,'2011/12/18','2011/1/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,9,9600,0.0,'2013/3/3','2013/5/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,38,2600,0.0,'2011/2/25','2011/3/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,50,6500,0.0,'2012/4/17','2012/6/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,34,100,0.0,'2012/2/7','2012/4/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,2,10000,0.0,'2016/9/6','2016/11/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,12,7400,0.0,'2012/10/6','2012/1/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,28,4700,0.0,'2014/7/26','2014/8/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,33,3500,0.0,'2013/11/14','2013/1/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,49,1700,0.0,'2011/12/12','2012/3/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,40,8400,0.0,'2016/4/13','2016/7/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,34,5800,0.0,'2011/9/16','2011/11/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,43,3400,0.0,'2012/2/10','2012/4/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,23,500,0.0,'2015/10/12','2015/12/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,3,3500,0.0,'2014/6/3','2014/8/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,28,2600,0.0,'2014/1/26','2014/2/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,5,1500,0.0,'2015/4/11','2015/5/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,5,100,0.0,'2012/12/5','2013/2/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,12,200,0.0,'2011/10/20','2011/12/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,14,300,0.0,'2012/4/15','2012/6/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,33,7100,0.0,'2013/6/7','2013/9/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,34,5200,0.0,'2016/7/27','2016/9/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,37,9700,0.0,'2016/2/5','2016/4/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,11,4000,0.0,'2014/3/27','2014/5/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,4,800,0.0,'2012/9/25','2012/11/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,12,9600,0.0,'2014/11/9','2015/2/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,50,4200,0.0,'2014/5/16','2014/7/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,47,2800,0.0,'2013/7/14','2013/9/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,21,4100,0.0,'2014/3/23','2014/4/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,9,1100,0.0,'2014/8/15','2014/11/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,47,2300,0.0,'2013/11/15','2014/2/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,37,1500,0.0,'2014/11/23','2014/1/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,29,6500,0.0,'2011/7/6','2011/10/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,21,1000,0.0,'2011/12/12','2012/2/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(18,5,1700,0.0,'2015/7/19','2015/9/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,50,900,0.0,'2016/3/18','2016/6/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,49,7300,0.0,'2015/3/16','2015/5/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,14,3300,0.0,'2011/9/8','2011/11/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,44,4900,0.0,'2016/11/25','2016/12/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,23,5100,0.0,'2015/6/20','2015/8/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,7,4000,0.0,'2011/8/6','2011/11/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,37,3600,0.0,'2011/2/7','2011/4/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,13,9300,0.0,'2016/3/13','2016/5/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,9,6700,0.0,'2014/10/4','2014/12/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,48,1200,0.0,'2011/11/26','2011/12/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,13,1700,0.0,'2011/1/6','2011/3/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,17,8300,0.0,'2014/3/1','2014/5/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,48,8500,0.0,'2012/5/18','2012/6/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,37,5000,0.0,'2016/3/11','2016/4/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,22,9800,0.0,'2013/7/8','2013/9/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,20,8800,0.0,'2012/7/10','2012/10/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,23,1700,0.0,'2013/9/18','2013/11/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,31,3500,0.0,'2016/3/3','2016/6/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,6,3200,0.0,'2014/9/20','2014/11/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,30,5800,0.0,'2012/12/28','2013/2/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,11,8700,0.0,'2015/4/9','2015/6/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(18,29,1400,0.0,'2015/8/18','2015/10/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,45,6700,0.0,'2011/6/23','2011/7/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,46,6200,0.0,'2014/2/14','2014/5/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,50,6400,0.0,'2011/10/20','2011/12/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,37,2900,0.0,'2016/2/21','2016/3/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,47,2100,0.0,'2012/3/26','2012/5/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,20,1200,0.0,'2012/4/25','2012/5/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,35,9000,0.0,'2016/5/25','2016/7/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,9,9900,0.0,'2011/3/17','2011/6/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(13,22,5800,0.0,'2014/9/26','2014/11/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,40,4200,0.0,'2011/2/16','2011/4/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,39,600,0.0,'2013/3/16','2013/5/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,16,700,0.0,'2014/5/6','2014/7/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,46,1600,0.0,'2014/5/2','2014/7/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,23,5100,0.0,'2015/2/21','2015/4/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,28,1300,0.0,'2014/5/28','2014/7/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(13,41,9500,0.0,'2016/10/9','2016/12/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,27,400,0.0,'2011/4/25','2011/5/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,34,7200,0.0,'2016/7/14','2016/8/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,33,7900,0.0,'2014/2/16','2014/5/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,46,3100,0.0,'2016/6/15','2016/8/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,12,4400,0.0,'2011/1/25','2011/4/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,21,8000,0.0,'2016/5/1','2016/7/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,29,500,0.0,'2011/5/28','2011/7/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,44,1300,0.0,'2012/9/24','2012/11/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,6,3200,0.0,'2012/9/20','2012/12/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,32,8300,0.0,'2011/9/18','2011/11/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,4,2400,0.0,'2015/8/15','2015/9/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,24,5600,0.0,'2011/6/15','2011/7/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,28,5500,0.0,'2013/12/18','2014/2/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,3,4300,0.0,'2015/2/9','2015/4/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(18,3,3900,0.0,'2016/10/23','2016/12/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,19,2600,0.0,'2011/4/27','2011/6/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,36,4400,0.0,'2011/1/13','2011/3/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,12,4100,0.0,'2014/9/28','2014/12/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,44,6600,0.0,'2015/5/9','2015/7/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,10,8900,0.0,'2012/1/23','2012/3/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(18,40,7000,0.0,'2015/12/17','2016/2/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,42,900,0.0,'2011/5/21','2011/8/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,4,4500,0.0,'2016/10/24','2016/11/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,27,9500,0.0,'2016/7/1','2016/10/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,46,2200,0.0,'2013/3/13','2013/6/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,30,5600,0.0,'2016/5/22','2016/7/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,48,4300,0.0,'2011/1/21','2011/3/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,34,1100,0.0,'2013/7/12','2013/9/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,34,8100,0.0,'2012/10/27','2012/12/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,11,200,0.0,'2015/7/26','2015/9/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,15,5500,0.0,'2011/8/20','2011/10/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,9,4900,0.0,'2013/3/22','2013/4/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,27,7200,0.0,'2013/8/12','2013/9/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,37,4100,0.0,'2014/12/24','2014/1/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,31,1200,0.0,'2012/1/27','2012/2/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,28,8600,0.0,'2015/11/8','2015/1/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,3,3700,0.0,'2014/4/10','2014/7/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,29,600,0.0,'2015/4/7','2015/6/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,48,3200,0.0,'2014/5/1','2014/7/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,11,4700,0.0,'2013/11/4','2014/2/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,48,800,0.0,'2011/9/11','2011/10/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(18,37,7500,0.0,'2016/1/28','2016/3/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,8,2300,0.0,'2016/7/6','2016/9/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,20,2000,0.0,'2013/12/25','2014/3/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,34,1000,0.0,'2016/11/1','2016/1/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(18,43,8600,0.0,'2013/9/20','2013/11/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,35,9000,0.0,'2016/5/17','2016/7/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,27,2500,0.0,'2015/9/6','2015/11/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,29,6600,0.0,'2015/12/28','2015/1/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,6,7300,0.0,'2016/6/10','2016/8/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,8,3600,0.0,'2015/8/26','2015/9/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(12,23,1800,0.0,'2015/5/22','2015/7/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,28,7900,0.0,'2016/5/18','2016/8/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,11,5200,0.0,'2016/8/21','2016/10/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,13,3900,0.0,'2016/2/25','2016/5/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,25,7500,0.0,'2015/7/28','2015/10/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,43,4100,0.0,'2011/5/15','2011/8/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,17,2100,0.0,'2016/10/10','2016/1/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,21,5400,0.0,'2011/9/9','2011/12/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,23,100,0.0,'2012/2/1','2012/4/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,50,800,0.0,'2012/8/10','2012/11/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,4,1100,0.0,'2011/10/15','2011/1/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,41,8400,0.0,'2011/12/22','2011/1/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,37,3300,0.0,'2016/2/5','2016/4/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,44,3600,0.0,'2015/10/18','2015/1/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,50,7600,0.0,'2011/8/13','2011/10/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(12,14,5900,0.0,'2013/1/7','2013/3/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,14,5700,0.0,'2014/8/13','2014/11/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,12,9900,0.0,'2013/4/25','2013/5/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,29,2200,0.0,'2016/6/7','2016/9/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,47,9700,0.0,'2015/5/24','2015/8/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,2,3000,0.0,'2014/10/11','2014/12/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,50,1700,0.0,'2016/11/12','2017/2/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,5,2500,0.0,'2011/8/18','2011/11/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,41,8800,0.0,'2013/6/26','2013/7/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,35,9300,0.0,'2013/7/11','2013/10/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,13,3500,0.0,'2011/9/17','2011/11/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,36,9700,0.0,'2015/1/20','2015/2/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,32,6200,0.0,'2014/12/21','2015/3/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,3,700,0.0,'2013/9/16','2013/11/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,33,5000,0.0,'2015/4/4','2015/6/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,32,7200,0.0,'2014/12/12','2014/1/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,18,900,0.0,'2014/9/17','2014/12/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,13,5100,0.0,'2016/1/27','2016/3/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,33,10000,0.0,'2011/11/11','2011/1/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,47,9800,0.0,'2013/8/23','2013/11/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,48,8200,0.0,'2012/3/12','2012/5/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,35,3500,0.0,'2011/6/16','2011/8/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(18,48,8000,0.0,'2011/10/13','2011/11/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,15,5500,0.0,'2016/9/7','2016/11/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,37,600,0.0,'2016/4/25','2016/7/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,45,9700,0.0,'2012/11/20','2012/1/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,19,7600,0.0,'2012/3/8','2012/5/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,38,3000,0.0,'2015/10/18','2015/12/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,2,900,0.0,'2015/9/16','2015/11/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(18,45,8200,0.0,'2016/10/28','2016/12/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(12,32,6100,0.0,'2015/11/14','2016/2/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,17,3400,0.0,'2013/2/19','2013/3/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,38,9400,0.0,'2011/4/15','2011/6/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,19,4300,0.0,'2011/2/16','2011/4/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,42,8400,0.0,'2014/2/11','2014/4/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,18,1600,0.0,'2012/8/25','2012/10/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,35,700,0.0,'2011/4/19','2011/5/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,21,3500,0.0,'2011/6/23','2011/8/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,29,3700,0.0,'2014/1/27','2014/2/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,14,3500,0.0,'2011/11/25','2012/2/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(13,31,9000,0.0,'2011/3/1','2011/5/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(13,17,9500,0.0,'2015/6/3','2015/8/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,9,7900,0.0,'2014/11/12','2015/2/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,23,4800,0.0,'2011/7/11','2011/9/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,49,2300,0.0,'2014/3/24','2014/6/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,16,1300,0.0,'2016/1/1','2016/3/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,5,5300,0.0,'2012/8/10','2012/10/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,35,8300,0.0,'2011/10/28','2011/11/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,19,2000,0.0,'2012/1/19','2012/4/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,50,6700,0.0,'2014/11/20','2014/12/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,21,4300,0.0,'2012/1/2','2012/3/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(18,25,1100,0.0,'2015/12/6','2016/3/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,37,1300,0.0,'2016/10/28','2016/11/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,42,5100,0.0,'2014/7/2','2014/9/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,39,8400,0.0,'2016/10/20','2016/11/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(12,19,4500,0.0,'2011/8/6','2011/11/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,7,5000,0.0,'2013/12/14','2014/2/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,16,4300,0.0,'2014/7/24','2014/9/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,50,7600,0.0,'2015/10/22','2015/12/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,45,8200,0.0,'2015/12/10','2016/3/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,47,9400,0.0,'2015/5/18','2015/7/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,12,10000,0.0,'2015/10/1','2015/1/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,22,5700,0.0,'2015/9/4','2015/12/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,14,100,0.0,'2014/4/17','2014/7/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(13,26,6200,0.0,'2013/11/15','2013/1/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(3,47,900,0.0,'2011/11/18','2011/12/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,17,3700,0.0,'2013/5/7','2013/7/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,21,4700,0.0,'2015/7/28','2015/8/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,33,2000,0.0,'2012/1/18','2012/4/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,5,200,0.0,'2014/6/22','2014/9/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(13,8,6100,0.0,'2016/9/21','2016/11/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,32,7500,0.0,'2012/5/13','2012/6/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,21,7100,0.0,'2013/8/10','2013/10/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,44,2100,0.0,'2011/5/18','2011/8/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,44,7000,0.0,'2011/5/22','2011/7/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,38,2900,0.0,'2014/1/7','2014/4/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,42,6000,0.0,'2013/1/6','2013/3/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(18,47,1700,0.0,'2016/10/20','2016/12/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,48,7500,0.0,'2011/7/3','2011/9/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,30,7400,0.0,'2015/3/18','2015/4/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,24,6500,0.0,'2016/10/25','2016/12/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,18,6300,0.0,'2012/12/24','2013/3/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,34,300,0.0,'2014/7/4','2014/9/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(14,37,1000,0.0,'2012/8/5','2012/10/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,11,5200,0.0,'2014/9/4','2014/12/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,8,900,0.0,'2013/12/17','2014/2/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,25,600,0.0,'2016/4/5','2016/6/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,2,8600,0.0,'2013/5/15','2013/6/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,45,5900,0.0,'2012/10/21','2012/12/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,13,4600,0.0,'2014/3/25','2014/5/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(1,21,9200,0.0,'2014/5/20','2014/6/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(17,33,4500,0.0,'2015/9/24','2015/12/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(22,1,7200,0.0,'2015/7/15','2015/10/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,13,5600,0.0,'2016/12/13','2017/2/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(10,24,3600,0.0,'2012/5/23','2012/7/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,21,9700,0.0,'2011/1/4','2011/3/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,13,9500,0.0,'2016/2/17','2016/4/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(12,19,3600,0.0,'2012/7/4','2012/9/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(26,11,3800,0.0,'2016/11/26','2016/12/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(23,2,7100,0.0,'2014/3/23','2014/5/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(6,15,9200,0.0,'2012/1/16','2012/4/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(9,12,3500,0.0,'2012/11/10','2013/2/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,8,1900,0.0,'2014/11/27','2014/12/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,40,6400,0.0,'2011/3/2','2011/5/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,13,4100,0.0,'2015/3/27','2015/4/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,39,6600,0.0,'2014/7/10','2014/10/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(21,13,9300,0.0,'2013/11/18','2013/1/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(2,24,9000,0.0,'2014/8/7','2014/10/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(24,7,6700,0.0,'2014/5/1','2014/8/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(12,42,8500,0.0,'2015/7/26','2015/9/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(12,36,7700,0.0,'2015/12/21','2015/1/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,44,5700,0.0,'2013/8/24','2013/10/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(20,41,7800,0.0,'2014/9/22','2014/10/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(19,27,9800,0.0,'2016/11/21','2017/2/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(15,39,2200,0.0,'2014/4/27','2014/5/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(8,22,6100,0.0,'2016/6/9','2016/7/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(4,30,6900,0.0,'2014/10/12','2014/1/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(16,5,6500,0.0,'2016/12/24','2017/2/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(7,15,3500,0.0,'2014/12/16','2015/3/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(11,24,3800,0.0,'2016/10/25','2016/11/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(5,14,6600,0.0,'2013/7/17','2013/9/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date]) VALUES(25,42,4400,0.0,'2012/1/9','2012/4/28')
GO


INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(2,1) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(96,1) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(13,2) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(16,2) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(26,2) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(41,2) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(55,2) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(69,2) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(97,2) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(49,3) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(82,3) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(102,4) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(35,5) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(82,5) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(98,5) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(7,6) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(54,6) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(17,6) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(100,7) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(101,7) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(19,8) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(42,8) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(82,8) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(9,9) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(19,9) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(1,10) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(35,10) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(87,10) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(82,10) 
GO
INSERT INTO [dbo].[seas_countries]([sea_id],[country_id]) VALUES(57,10) 
GO

INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(468,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(246,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(104,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(186,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(422,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(272,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(74,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(431,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(12,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(249,40,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(467,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(77,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(436,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(245,7,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(291,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(287,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(203,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(351,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(214,45,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(489,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(228,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(154,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(304,23,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(140,44,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(170,32,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(413,18,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(248,21,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(256,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(421,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(452,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(269,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(74,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(386,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(402,36,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(440,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(423,27,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(467,23,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(164,42,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(297,43,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(460,9,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(305,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(407,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(453,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(106,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(212,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(360,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(239,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(345,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(105,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(362,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(169,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(95,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(437,36,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(487,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(142,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(228,42,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(57,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(350,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(147,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(409,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(246,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(90,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(244,35,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(259,45,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(295,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(20,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(9,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(198,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(103,27,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(402,42,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(4,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(369,35,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(461,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(479,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(494,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(181,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(126,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(84,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(381,35,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(349,9,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(247,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(235,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(235,45,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(340,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(218,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(222,47,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(421,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(218,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(274,23,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(315,18,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(66,40,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(406,32,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(377,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(452,46,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(261,35,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(265,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(360,46,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(475,49,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(475,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(188,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(57,27,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(236,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(229,7,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(164,47,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(316,5,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(103,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(193,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(298,35,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(130,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(105,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(178,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(167,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(394,9,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(135,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(458,6,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(154,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(179,40,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(232,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(290,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(356,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(103,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(91,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(50,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(308,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(225,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(196,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(255,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(454,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(444,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(262,16,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(351,11,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(342,44,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(22,11,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(225,35,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(368,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(324,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(249,42,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(166,46,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(71,18,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(134,7,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(71,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(335,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(303,9,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(369,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(338,40,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(358,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(208,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(208,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(451,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(454,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(218,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(491,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(243,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(304,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(231,42,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(79,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(484,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(450,16,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(214,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(449,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(433,49,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(238,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(208,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(143,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(195,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(211,27,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(233,33,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(9,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(379,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(422,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(327,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(144,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(299,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(373,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(415,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(260,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(54,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(368,49,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(135,46,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(500,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(361,21,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(349,45,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(486,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(313,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(254,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(76,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(266,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(45,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(290,11,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(352,18,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(267,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(156,7,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(70,44,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(120,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(442,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(346,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(160,42,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(69,27,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(237,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(482,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(24,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(378,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(63,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(471,36,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(102,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(132,5,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(5,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(266,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(328,21,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(352,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(304,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(106,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(230,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(428,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(426,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(47,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(346,16,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(329,45,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(31,16,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(268,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(181,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(199,46,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(324,42,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(499,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(292,16,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(70,36,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(118,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(15,47,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(410,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(191,39,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(184,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(141,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(363,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(116,35,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(36,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(194,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(153,43,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(441,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(278,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(469,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(128,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(421,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(497,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(443,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(368,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(73,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(411,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(61,49,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(32,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(462,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(365,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(243,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(78,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(356,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(215,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(33,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(207,7,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(296,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(334,7,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(205,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(45,21,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(483,45,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(214,16,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(11,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(180,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(294,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(113,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(304,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(271,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(232,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(390,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(96,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(98,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(340,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(63,5,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(450,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(348,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(241,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(424,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(410,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(323,49,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(40,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(352,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(444,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(32,50,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(78,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(128,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(422,16,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(130,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(87,44,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(94,9,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(412,9,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(437,21,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(116,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(247,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(394,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(259,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(187,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(247,49,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(64,9,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(397,14,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(340,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(494,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(487,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(67,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(169,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(50,33,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(102,43,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(93,43,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(82,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(413,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(95,49,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(159,11,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(442,23,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(112,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(375,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(306,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(468,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(259,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(325,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(215,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(36,27,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(26,44,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(40,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(435,11,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(492,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(228,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(69,47,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(20,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(132,11,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(9,47,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(20,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(494,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(427,31,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(263,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(148,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(184,8,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(197,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(191,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(76,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(261,41,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(67,18,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(33,10,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(131,33,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(261,11,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(198,33,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(466,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(249,32,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(436,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(52,30,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(94,5,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(132,23,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(227,19,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(188,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(477,37,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(391,15,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(257,36,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(462,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(272,13,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(432,43,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(73,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(245,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(264,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(216,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(323,40,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(495,43,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(121,20,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(413,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(181,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(189,17,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(383,12,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(247,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(442,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(106,2,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(353,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(85,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(480,40,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(68,47,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(337,1,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(34,22,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(433,18,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(70,38,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(399,48,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(231,3,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(176,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(498,47,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(435,34,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(255,4,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(187,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(136,32,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(265,18,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(346,24,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(200,23,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(232,29,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(418,43,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(98,26,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(465,25,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(264,28,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(92,6,0)
GO
INSERT INTO [dbo].[accompanying]([offer_id],[client_id],[discount]) VALUES(439,24,0)
GO