INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,39,8900,0.0,'2015/10/9','2015/12/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,42,2200,0.0,'2012/8/17','2012/11/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,30,4400,0.0,'2015/3/1','2015/5/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,48,7400,0.0,'2013/1/11','2013/3/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,15,6600,0.0,'2011/5/12','2011/7/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,28,5900,0.0,'2016/10/19','2016/1/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,23,9600,0.0,'2015/1/1','2015/3/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,13,8100,0.0,'2012/2/7','2012/5/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,3,9900,0.0,'2016/6/22','2016/9/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,18,4100,0.0,'2014/6/5','2014/8/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,22,7600,0.0,'2012/10/14','2012/12/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,7,8300,0.0,'2015/9/6','2015/11/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,39,4600,0.0,'2014/12/15','2014/1/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,26,400,0.0,'2015/8/11','2015/11/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,33,6500,0.0,'2012/12/21','2013/2/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,1,8800,0.0,'2014/10/8','2014/12/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,38,7200,0.0,'2015/7/24','2015/8/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,12,7500,0.0,'2011/12/6','2012/2/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,8,4100,0.0,'2014/12/17','2015/2/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,12,400,0.0,'2011/11/13','2011/1/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,20,7500,0.0,'2013/1/3','2013/3/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,4,7200,0.0,'2016/2/14','2016/3/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,12,6300,0.0,'2012/8/28','2012/11/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,29,5500,0.0,'2012/7/10','2012/9/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,38,200,0.0,'2012/5/22','2012/8/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,20,800,0.0,'2014/12/25','2015/2/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,2,1000,0.0,'2016/3/23','2016/6/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,43,5400,0.0,'2011/4/19','2011/6/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,2,1700,0.0,'2016/8/11','2016/10/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,39,4500,0.0,'2013/2/6','2013/5/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,35,400,0.0,'2015/7/27','2015/10/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,18,8800,0.0,'2014/6/6','2014/8/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,20,2400,0.0,'2012/12/13','2013/2/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,36,8700,0.0,'2013/11/18','2014/2/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,31,4700,0.0,'2012/4/26','2012/7/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(39,41,3800,0.0,'2016/4/7','2016/7/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(39,40,8100,0.0,'2016/12/14','2017/3/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,24,300,0.0,'2015/4/26','2015/7/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,16,1800,0.0,'2012/12/6','2013/3/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,37,7100,0.0,'2013/5/7','2013/6/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,7,900,0.0,'2014/8/3','2014/11/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,20,300,0.0,'2016/8/21','2016/10/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,22,3500,0.0,'2013/8/16','2013/11/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,31,7200,0.0,'2015/9/25','2015/10/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(38,16,2000,0.0,'2011/2/5','2011/5/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,30,1800,0.0,'2013/3/7','2013/6/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,48,2600,0.0,'2011/1/3','2011/3/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,43,2400,0.0,'2011/6/16','2011/8/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,8,5100,0.0,'2015/11/13','2015/1/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,15,5200,0.0,'2012/12/26','2013/2/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,6,5100,0.0,'2012/2/20','2012/4/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,23,1700,0.0,'2012/9/7','2012/12/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,12,5800,0.0,'2012/3/18','2012/5/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,32,900,0.0,'2011/11/9','2012/2/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,43,9100,0.0,'2013/5/16','2013/7/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,47,9600,0.0,'2012/12/2','2013/3/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,25,1900,0.0,'2012/10/21','2012/1/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,3,3200,0.0,'2016/11/7','2016/1/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,32,5500,0.0,'2011/8/2','2011/10/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,35,4500,0.0,'2011/11/6','2011/12/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,1,4600,0.0,'2016/7/21','2016/9/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,14,4100,0.0,'2012/10/15','2012/1/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,12,8400,0.0,'2011/11/11','2011/1/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,43,9600,0.0,'2016/9/25','2016/12/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,32,8400,0.0,'2015/2/10','2015/4/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,24,7200,0.0,'2013/6/18','2013/8/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,36,8000,0.0,'2014/11/23','2014/12/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,40,6700,0.0,'2012/12/18','2013/2/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,37,4200,0.0,'2011/2/7','2011/5/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,12,8500,0.0,'2013/10/6','2013/12/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(39,24,4200,0.0,'2012/8/4','2012/10/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,17,4900,0.0,'2016/9/10','2016/11/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,10,8500,0.0,'2011/12/17','2012/2/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,6,1800,0.0,'2012/12/23','2013/2/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,12,6300,0.0,'2014/2/10','2014/4/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,3,7800,0.0,'2016/3/9','2016/5/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,41,5400,0.0,'2011/6/4','2011/9/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,23,1800,0.0,'2016/12/23','2017/2/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,36,2100,0.0,'2012/3/13','2012/4/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,6,4600,0.0,'2014/11/8','2015/2/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,20,4600,0.0,'2012/6/5','2012/9/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(39,37,8700,0.0,'2014/7/11','2014/10/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,1,6700,0.0,'2012/11/6','2012/1/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,13,200,0.0,'2015/12/15','2015/1/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,4,8700,0.0,'2012/7/3','2012/9/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,28,1200,0.0,'2015/8/28','2015/11/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,40,9800,0.0,'2015/4/16','2015/5/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,5,9600,0.0,'2016/6/18','2016/8/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,48,3500,0.0,'2015/8/5','2015/10/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,11,5700,0.0,'2011/10/12','2011/12/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,44,1000,0.0,'2013/5/1','2013/8/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,12,3600,0.0,'2012/10/9','2012/11/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,43,4600,0.0,'2015/2/7','2015/4/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,31,3200,0.0,'2011/10/1','2011/12/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,48,5600,0.0,'2014/2/2','2014/4/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,37,9100,0.0,'2014/7/18','2014/8/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,12,100,0.0,'2012/2/12','2012/5/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,39,300,0.0,'2016/9/2','2016/11/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,35,1900,0.0,'2014/12/1','2015/2/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,39,9200,0.0,'2014/8/18','2014/11/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,5,800,0.0,'2013/5/15','2013/7/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,21,8400,0.0,'2011/8/6','2011/11/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,39,1900,0.0,'2011/9/12','2011/11/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,45,6600,0.0,'2013/8/11','2013/10/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,46,6000,0.0,'2013/12/22','2013/1/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,28,8400,0.0,'2014/3/2','2014/6/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,39,9200,0.0,'2012/2/18','2012/3/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,23,7200,0.0,'2013/3/4','2013/6/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,22,3500,0.0,'2014/8/17','2014/10/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,5,4700,0.0,'2013/11/14','2013/1/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,20,5800,0.0,'2014/6/28','2014/7/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,24,2200,0.0,'2014/12/21','2015/3/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,43,2600,0.0,'2016/3/24','2016/6/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,10,2100,0.0,'2012/7/7','2012/10/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,33,9100,0.0,'2014/7/18','2014/8/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,42,600,0.0,'2012/4/21','2012/7/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,45,8200,0.0,'2013/6/11','2013/8/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,47,9400,0.0,'2013/12/9','2014/2/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,16,9700,0.0,'2014/4/21','2014/7/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,27,6100,0.0,'2012/6/28','2012/9/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,10,8300,0.0,'2015/5/22','2015/7/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,19,9300,0.0,'2016/11/5','2017/2/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,30,5500,0.0,'2015/12/1','2016/2/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,12,3200,0.0,'2013/9/12','2013/10/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,33,3400,0.0,'2014/8/9','2014/11/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(39,10,1900,0.0,'2016/4/26','2016/6/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,4,2100,0.0,'2016/8/26','2016/10/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,14,4700,0.0,'2012/7/21','2012/10/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,32,6900,0.0,'2014/8/25','2014/10/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,14,7900,0.0,'2015/6/4','2015/9/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,32,7000,0.0,'2015/11/7','2015/1/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,50,5500,0.0,'2013/11/17','2014/2/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,5,9700,0.0,'2011/9/9','2011/12/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,30,4400,0.0,'2014/8/3','2014/10/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,35,9200,0.0,'2013/7/7','2013/8/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,20,2700,0.0,'2012/2/1','2012/4/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,45,5500,0.0,'2011/2/7','2011/5/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,28,1400,0.0,'2016/8/14','2016/10/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,16,6900,0.0,'2016/4/15','2016/6/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(39,21,3800,0.0,'2016/4/12','2016/6/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,1,2100,0.0,'2015/3/22','2015/4/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,29,400,0.0,'2012/4/4','2012/6/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,7,2500,0.0,'2011/10/2','2011/12/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,10,5200,0.0,'2016/3/3','2016/6/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,5,3300,0.0,'2014/3/2','2014/6/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,6,3800,0.0,'2015/6/16','2015/8/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,2,7600,0.0,'2013/9/7','2013/12/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,17,1300,0.0,'2013/8/5','2013/11/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,8,5400,0.0,'2014/4/15','2014/6/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,15,1300,0.0,'2013/11/20','2013/1/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,19,1000,0.0,'2013/1/14','2013/4/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,18,3700,0.0,'2013/3/24','2013/4/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(38,10,3200,0.0,'2016/8/10','2016/10/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(38,2,7800,0.0,'2012/5/18','2012/7/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,9,200,0.0,'2016/8/11','2016/9/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,49,7800,0.0,'2015/6/5','2015/8/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,15,1000,0.0,'2012/5/1','2012/8/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,39,5300,0.0,'2013/10/23','2013/1/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,4,1500,0.0,'2015/11/28','2016/2/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,48,2600,0.0,'2012/4/28','2012/5/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,12,3700,0.0,'2012/9/21','2012/10/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(38,47,5300,0.0,'2014/7/4','2014/9/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,43,4600,0.0,'2016/11/2','2016/1/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,16,7300,0.0,'2012/5/19','2012/6/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,17,6600,0.0,'2011/12/20','2012/3/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,6,100,0.0,'2014/8/28','2014/11/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(38,13,8900,0.0,'2015/5/17','2015/7/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(44,43,7900,0.0,'2012/9/22','2012/11/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,1,6400,0.0,'2016/6/7','2016/8/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,23,2600,0.0,'2016/2/5','2016/5/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,3,3900,0.0,'2012/6/12','2012/9/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(39,39,3000,0.0,'2016/7/8','2016/10/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,49,6100,0.0,'2015/4/4','2015/6/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(44,3,9400,0.0,'2014/12/24','2015/2/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,40,8900,0.0,'2011/8/12','2011/10/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(44,22,3700,0.0,'2013/11/9','2014/2/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,48,4400,0.0,'2015/6/10','2015/8/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,19,7000,0.0,'2012/11/13','2013/2/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,31,8900,0.0,'2015/9/28','2015/10/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,11,6200,0.0,'2016/8/16','2016/10/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(39,25,4800,0.0,'2011/12/18','2012/2/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(39,48,700,0.0,'2011/3/3','2011/5/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,32,6700,0.0,'2013/4/22','2013/6/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(44,5,9300,0.0,'2013/1/1','2013/4/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,38,7700,0.0,'2013/9/21','2013/10/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,12,2600,0.0,'2015/2/14','2015/3/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,34,3600,0.0,'2012/3/26','2012/6/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,1,4400,0.0,'2015/5/16','2015/7/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,9,6000,0.0,'2012/6/27','2012/7/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,21,6800,0.0,'2015/12/14','2016/2/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,49,9700,0.0,'2014/1/14','2014/3/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,1,9800,0.0,'2011/7/16','2011/9/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,39,8600,0.0,'2014/5/27','2014/6/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,29,4000,0.0,'2015/3/3','2015/6/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,28,8800,0.0,'2015/9/10','2015/11/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,12,9000,0.0,'2012/10/2','2012/1/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,43,2200,0.0,'2014/3/8','2014/5/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,21,8200,0.0,'2016/1/2','2016/3/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,45,3400,0.0,'2013/7/12','2013/9/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,1,700,0.0,'2012/10/27','2012/1/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,45,5000,0.0,'2012/7/19','2012/9/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,36,3300,0.0,'2013/5/26','2013/6/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,17,300,0.0,'2011/3/28','2011/5/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,35,5600,0.0,'2012/1/24','2012/3/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,1,4900,0.0,'2011/3/11','2011/4/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,38,7300,0.0,'2012/11/6','2013/2/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,25,9500,0.0,'2016/1/26','2016/2/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,10,7400,0.0,'2016/11/25','2016/1/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,46,1700,0.0,'2016/2/3','2016/5/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,29,6000,0.0,'2014/11/27','2015/2/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,38,400,0.0,'2011/4/15','2011/6/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,29,1400,0.0,'2011/2/1','2011/4/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,49,2500,0.0,'2013/5/15','2013/8/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(38,9,6400,0.0,'2015/4/10','2015/6/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,1,4500,0.0,'2011/10/21','2011/11/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,21,7500,0.0,'2014/7/19','2014/8/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,49,2900,0.0,'2012/5/11','2012/7/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,23,8100,0.0,'2015/1/18','2015/3/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,7,800,0.0,'2013/7/21','2013/8/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,39,9800,0.0,'2015/7/3','2015/9/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,48,100,0.0,'2014/10/25','2014/1/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,45,7700,0.0,'2012/4/6','2012/6/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,50,8900,0.0,'2013/4/7','2013/7/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,3,1300,0.0,'2013/3/27','2013/4/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,28,5500,0.0,'2013/4/27','2013/5/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,5,4000,0.0,'2012/5/27','2012/7/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,50,7300,0.0,'2013/6/21','2013/9/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,13,1200,0.0,'2014/3/24','2014/5/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,43,500,0.0,'2016/11/27','2016/12/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,22,5700,0.0,'2014/1/22','2014/2/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,38,4200,0.0,'2013/9/25','2013/12/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,48,400,0.0,'2016/9/22','2016/11/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,13,6800,0.0,'2014/9/13','2014/12/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,31,9500,0.0,'2014/10/20','2014/1/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,45,3500,0.0,'2012/9/12','2012/11/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,10,7200,0.0,'2011/9/14','2011/12/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,2,1200,0.0,'2014/12/6','2015/3/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,13,9100,0.0,'2013/5/11','2013/7/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(38,41,2400,0.0,'2013/7/11','2013/9/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,2,9100,0.0,'2011/12/18','2011/1/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,9,9600,0.0,'2013/3/3','2013/5/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,38,2600,0.0,'2011/2/25','2011/3/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,50,6500,0.0,'2012/4/17','2012/6/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,34,100,0.0,'2012/2/7','2012/4/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,2,10000,0.0,'2016/9/6','2016/11/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,12,7400,0.0,'2012/10/6','2012/1/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,28,4700,0.0,'2014/7/26','2014/8/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,33,3500,0.0,'2013/11/14','2013/1/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,49,1700,0.0,'2011/12/12','2012/3/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,40,8400,0.0,'2016/4/13','2016/7/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,34,5800,0.0,'2011/9/16','2011/11/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,43,3400,0.0,'2012/2/10','2012/4/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,23,500,0.0,'2015/10/12','2015/12/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,3,3500,0.0,'2014/6/3','2014/8/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,28,2600,0.0,'2014/1/26','2014/2/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,5,1500,0.0,'2015/4/11','2015/5/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,5,100,0.0,'2012/12/5','2013/2/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,12,200,0.0,'2011/10/20','2011/12/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,14,300,0.0,'2012/4/15','2012/6/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,33,7100,0.0,'2013/6/7','2013/9/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,34,5200,0.0,'2016/7/27','2016/9/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,37,9700,0.0,'2016/2/5','2016/4/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,11,4000,0.0,'2014/3/27','2014/5/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,4,800,0.0,'2012/9/25','2012/11/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,12,9600,0.0,'2014/11/9','2015/2/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,50,4200,0.0,'2014/5/16','2014/7/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,47,2800,0.0,'2013/7/14','2013/9/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,21,4100,0.0,'2014/3/23','2014/4/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,9,1100,0.0,'2014/8/15','2014/11/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,47,2300,0.0,'2013/11/15','2014/2/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,37,1500,0.0,'2014/11/23','2014/1/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,29,6500,0.0,'2011/7/6','2011/10/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,21,1000,0.0,'2011/12/12','2012/2/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(44,5,1700,0.0,'2015/7/19','2015/9/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,50,900,0.0,'2016/3/18','2016/6/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,49,7300,0.0,'2015/3/16','2015/5/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,14,3300,0.0,'2011/9/8','2011/11/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,44,4900,0.0,'2016/11/25','2016/12/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,23,5100,0.0,'2015/6/20','2015/8/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,7,4000,0.0,'2011/8/6','2011/11/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,37,3600,0.0,'2011/2/7','2011/4/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,13,9300,0.0,'2016/3/13','2016/5/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,9,6700,0.0,'2014/10/4','2014/12/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,48,1200,0.0,'2011/11/26','2011/12/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,13,1700,0.0,'2011/1/6','2011/3/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,17,8300,0.0,'2014/3/1','2014/5/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,48,8500,0.0,'2012/5/18','2012/6/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,37,5000,0.0,'2016/3/11','2016/4/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,22,9800,0.0,'2013/7/8','2013/9/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,20,8800,0.0,'2012/7/10','2012/10/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,23,1700,0.0,'2013/9/18','2013/11/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,31,3500,0.0,'2016/3/3','2016/6/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,6,3200,0.0,'2014/9/20','2014/11/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,30,5800,0.0,'2012/12/28','2013/2/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,11,8700,0.0,'2015/4/9','2015/6/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(44,29,1400,0.0,'2015/8/18','2015/10/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,45,6700,0.0,'2011/6/23','2011/7/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,46,6200,0.0,'2014/2/14','2014/5/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,50,6400,0.0,'2011/10/20','2011/12/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,37,2900,0.0,'2016/2/21','2016/3/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,47,2100,0.0,'2012/3/26','2012/5/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,20,1200,0.0,'2012/4/25','2012/5/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,35,9000,0.0,'2016/5/25','2016/7/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,9,9900,0.0,'2011/3/17','2011/6/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(39,22,5800,0.0,'2014/9/26','2014/11/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,40,4200,0.0,'2011/2/16','2011/4/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,39,600,0.0,'2013/3/16','2013/5/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,16,700,0.0,'2014/5/6','2014/7/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,46,1600,0.0,'2014/5/2','2014/7/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,23,5100,0.0,'2015/2/21','2015/4/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,28,1300,0.0,'2014/5/28','2014/7/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(39,41,9500,0.0,'2016/10/9','2016/12/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,27,400,0.0,'2011/4/25','2011/5/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,34,7200,0.0,'2016/7/14','2016/8/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,33,7900,0.0,'2014/2/16','2014/5/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,46,3100,0.0,'2016/6/15','2016/8/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,12,4400,0.0,'2011/1/25','2011/4/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,21,8000,0.0,'2016/5/1','2016/7/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,29,500,0.0,'2011/5/28','2011/7/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,44,1300,0.0,'2012/9/24','2012/11/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,6,3200,0.0,'2012/9/20','2012/12/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,32,8300,0.0,'2011/9/18','2011/11/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,4,2400,0.0,'2015/8/15','2015/9/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,24,5600,0.0,'2011/6/15','2011/7/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,28,5500,0.0,'2013/12/18','2014/2/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,3,4300,0.0,'2015/2/9','2015/4/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(44,3,3900,0.0,'2016/10/23','2016/12/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,19,2600,0.0,'2011/4/27','2011/6/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,36,4400,0.0,'2011/1/13','2011/3/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,12,4100,0.0,'2014/9/28','2014/12/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,44,6600,0.0,'2015/5/9','2015/7/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,10,8900,0.0,'2012/1/23','2012/3/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(44,40,7000,0.0,'2015/12/17','2016/2/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,42,900,0.0,'2011/5/21','2011/8/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,4,4500,0.0,'2016/10/24','2016/11/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,27,9500,0.0,'2016/7/1','2016/10/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,46,2200,0.0,'2013/3/13','2013/6/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,30,5600,0.0,'2016/5/22','2016/7/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,48,4300,0.0,'2011/1/21','2011/3/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,34,1100,0.0,'2013/7/12','2013/9/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,34,8100,0.0,'2012/10/27','2012/12/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,11,200,0.0,'2015/7/26','2015/9/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,15,5500,0.0,'2011/8/20','2011/10/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,9,4900,0.0,'2013/3/22','2013/4/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,27,7200,0.0,'2013/8/12','2013/9/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,37,4100,0.0,'2014/12/24','2014/1/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,31,1200,0.0,'2012/1/27','2012/2/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,28,8600,0.0,'2015/11/8','2015/1/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,3,3700,0.0,'2014/4/10','2014/7/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,29,600,0.0,'2015/4/7','2015/6/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,48,3200,0.0,'2014/5/1','2014/7/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,11,4700,0.0,'2013/11/4','2014/2/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,48,800,0.0,'2011/9/11','2011/10/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(44,37,7500,0.0,'2016/1/28','2016/3/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,8,2300,0.0,'2016/7/6','2016/9/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,20,2000,0.0,'2013/12/25','2014/3/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,34,1000,0.0,'2016/11/1','2016/1/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(44,43,8600,0.0,'2013/9/20','2013/11/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,35,9000,0.0,'2016/5/17','2016/7/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,27,2500,0.0,'2015/9/6','2015/11/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,29,6600,0.0,'2015/12/28','2015/1/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,6,7300,0.0,'2016/6/10','2016/8/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,8,3600,0.0,'2015/8/26','2015/9/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(38,23,1800,0.0,'2015/5/22','2015/7/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,28,7900,0.0,'2016/5/18','2016/8/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,11,5200,0.0,'2016/8/21','2016/10/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,13,3900,0.0,'2016/2/25','2016/5/16')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,25,7500,0.0,'2015/7/28','2015/10/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,43,4100,0.0,'2011/5/15','2011/8/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,17,2100,0.0,'2016/10/10','2016/1/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,21,5400,0.0,'2011/9/9','2011/12/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,23,100,0.0,'2012/2/1','2012/4/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,50,800,0.0,'2012/8/10','2012/11/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,4,1100,0.0,'2011/10/15','2011/1/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,41,8400,0.0,'2011/12/22','2011/1/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,37,3300,0.0,'2016/2/5','2016/4/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,44,3600,0.0,'2015/10/18','2015/1/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,50,7600,0.0,'2011/8/13','2011/10/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(38,14,5900,0.0,'2013/1/7','2013/3/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,14,5700,0.0,'2014/8/13','2014/11/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,12,9900,0.0,'2013/4/25','2013/5/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,29,2200,0.0,'2016/6/7','2016/9/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,47,9700,0.0,'2015/5/24','2015/8/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,2,3000,0.0,'2014/10/11','2014/12/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,50,1700,0.0,'2016/11/12','2017/2/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,5,2500,0.0,'2011/8/18','2011/11/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,41,8800,0.0,'2013/6/26','2013/7/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,35,9300,0.0,'2013/7/11','2013/10/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,13,3500,0.0,'2011/9/17','2011/11/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,36,9700,0.0,'2015/1/20','2015/2/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,32,6200,0.0,'2014/12/21','2015/3/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,3,700,0.0,'2013/9/16','2013/11/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,33,5000,0.0,'2015/4/4','2015/6/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,32,7200,0.0,'2014/12/12','2014/1/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,18,900,0.0,'2014/9/17','2014/12/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,13,5100,0.0,'2016/1/27','2016/3/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,33,10000,0.0,'2011/11/11','2011/1/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,47,9800,0.0,'2013/8/23','2013/11/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,48,8200,0.0,'2012/3/12','2012/5/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,35,3500,0.0,'2011/6/16','2011/8/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(44,48,8000,0.0,'2011/10/13','2011/11/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,15,5500,0.0,'2016/9/7','2016/11/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,37,600,0.0,'2016/4/25','2016/7/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,45,9700,0.0,'2012/11/20','2012/1/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,19,7600,0.0,'2012/3/8','2012/5/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,38,3000,0.0,'2015/10/18','2015/12/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,2,900,0.0,'2015/9/16','2015/11/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(44,45,8200,0.0,'2016/10/28','2016/12/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(38,32,6100,0.0,'2015/11/14','2016/2/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,17,3400,0.0,'2013/2/19','2013/3/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,38,9400,0.0,'2011/4/15','2011/6/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,19,4300,0.0,'2011/2/16','2011/4/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,42,8400,0.0,'2014/2/11','2014/4/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,18,1600,0.0,'2012/8/25','2012/10/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,35,700,0.0,'2011/4/19','2011/5/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,21,3500,0.0,'2011/6/23','2011/8/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,29,3700,0.0,'2014/1/27','2014/2/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,14,3500,0.0,'2011/11/25','2012/2/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(39,31,9000,0.0,'2011/3/1','2011/5/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(39,17,9500,0.0,'2015/6/3','2015/8/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,9,7900,0.0,'2014/11/12','2015/2/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,23,4800,0.0,'2011/7/11','2011/9/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,49,2300,0.0,'2014/3/24','2014/6/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,16,1300,0.0,'2016/1/1','2016/3/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,5,5300,0.0,'2012/8/10','2012/10/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,35,8300,0.0,'2011/10/28','2011/11/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,19,2000,0.0,'2012/1/19','2012/4/23')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,50,6700,0.0,'2014/11/20','2014/12/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,21,4300,0.0,'2012/1/2','2012/3/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(44,25,1100,0.0,'2015/12/6','2016/3/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,37,1300,0.0,'2016/10/28','2016/11/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,42,5100,0.0,'2014/7/2','2014/9/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,39,8400,0.0,'2016/10/20','2016/11/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(38,19,4500,0.0,'2011/8/6','2011/11/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,7,5000,0.0,'2013/12/14','2014/2/14')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,16,4300,0.0,'2014/7/24','2014/9/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,50,7600,0.0,'2015/10/22','2015/12/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,45,8200,0.0,'2015/12/10','2016/3/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,47,9400,0.0,'2015/5/18','2015/7/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,12,10000,0.0,'2015/10/1','2015/1/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,22,5700,0.0,'2015/9/4','2015/12/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,14,100,0.0,'2014/4/17','2014/7/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(39,26,6200,0.0,'2013/11/15','2013/1/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(29,47,900,0.0,'2011/11/18','2011/12/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,17,3700,0.0,'2013/5/7','2013/7/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,21,4700,0.0,'2015/7/28','2015/8/5')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,33,2000,0.0,'2012/1/18','2012/4/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,5,200,0.0,'2014/6/22','2014/9/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(39,8,6100,0.0,'2016/9/21','2016/11/10')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,32,7500,0.0,'2012/5/13','2012/6/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,21,7100,0.0,'2013/8/10','2013/10/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,44,2100,0.0,'2011/5/18','2011/8/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,44,7000,0.0,'2011/5/22','2011/7/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,38,2900,0.0,'2014/1/7','2014/4/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,42,6000,0.0,'2013/1/6','2013/3/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(44,47,1700,0.0,'2016/10/20','2016/12/19')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,48,7500,0.0,'2011/7/3','2011/9/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,30,7400,0.0,'2015/3/18','2015/4/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,24,6500,0.0,'2016/10/25','2016/12/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,18,6300,0.0,'2012/12/24','2013/3/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,34,300,0.0,'2014/7/4','2014/9/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(40,37,1000,0.0,'2012/8/5','2012/10/21')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,11,5200,0.0,'2014/9/4','2014/12/17')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,8,900,0.0,'2013/12/17','2014/2/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,25,600,0.0,'2016/4/5','2016/6/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,2,8600,0.0,'2013/5/15','2013/6/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,45,5900,0.0,'2012/10/21','2012/12/25')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,13,4600,0.0,'2014/3/25','2014/5/24')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(27,21,9200,0.0,'2014/5/20','2014/6/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(43,33,4500,0.0,'2015/9/24','2015/12/4')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(48,1,7200,0.0,'2015/7/15','2015/10/7')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,13,5600,0.0,'2016/12/13','2017/2/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(36,24,3600,0.0,'2012/5/23','2012/7/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,21,9700,0.0,'2011/1/4','2011/3/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,13,9500,0.0,'2016/2/17','2016/4/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(38,19,3600,0.0,'2012/7/4','2012/9/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(52,11,3800,0.0,'2016/11/26','2016/12/1')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(49,2,7100,0.0,'2014/3/23','2014/5/13')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(32,15,9200,0.0,'2012/1/16','2012/4/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(35,12,3500,0.0,'2012/11/10','2013/2/12')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,8,1900,0.0,'2014/11/27','2014/12/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,40,6400,0.0,'2011/3/2','2011/5/26')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,13,4100,0.0,'2015/3/27','2015/4/11')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,39,6600,0.0,'2014/7/10','2014/10/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(47,13,9300,0.0,'2013/11/18','2013/1/2')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(28,24,9000,0.0,'2014/8/7','2014/10/20')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(50,7,6700,0.0,'2014/5/1','2014/8/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(38,42,8500,0.0,'2015/7/26','2015/9/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(38,36,7700,0.0,'2015/12/21','2015/1/18')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,44,5700,0.0,'2013/8/24','2013/10/27')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(46,41,7800,0.0,'2014/9/22','2014/10/15')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(45,27,9800,0.0,'2016/11/21','2017/2/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(41,39,2200,0.0,'2014/4/27','2014/5/22')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(34,22,6100,0.0,'2016/6/9','2016/7/3')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(30,30,6900,0.0,'2014/10/12','2014/1/28')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(42,5,6500,0.0,'2016/12/24','2017/2/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(33,15,3500,0.0,'2014/12/16','2015/3/8')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(37,24,3800,0.0,'2016/10/25','2016/11/9')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(31,14,6600,0.0,'2013/7/17','2013/9/6')
GO
INSERT INTO [dbo].[offer]([resort_id],[client_id],[price],[discount],[start_date],[end_date])
    VALUES(51,42,4400,0.0,'2012/1/9','2012/4/28')
GO