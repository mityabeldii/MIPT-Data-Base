INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Ильин', 'Ваган', 7 ,'+7(991)167-99-82', 'iliin@mymail.com', 'ул.Амосова д.38', '786842', 'AB786842', '1951/5/26')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Баранова', 'Афина', 10,' +7(974)111-87-27', 'baranova@mymail.com', 'ул.Амосова д.41', '487504', 'AB487504', '1978/12/1')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Соловьёва', 'Каролина', 9 ,'+7(937)915-17-21', 'solovieva@mymail.com', 'ул.Амосова д.48', '329275', 'AB329275', '1998/9/20')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Савельев', 'Аскар', 8 ,'+7(929)958-72-44', 'saveliev@mymail.com', 'ул.Амосова д.47', '946477', 'AB946477', '2003/9/6')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Александров', 'Виталий', 4 ,'+7(919)821-93-57', 'alexandrov@mymail.com', 'ул.Амосова д.63', '388296', 'AB388296', '1993/1/18')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Соловьёва', 'Софья', 4 ,'+7(911)763-42-66', 'solovieva_sophie@mymail.com', 'ул.Амосова д.58', '824492', 'AB824492', '2009/6/6')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Новиков', 'Давлат', 4 ,'+7(998)941-15-22', 'novikOFF@mymail.com', 'ул.Амосова д.68', '494557', 'AB494557', '2004/5/4')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Смирнова', 'Ангелина', 7 ,'+7(997)675-57-82', 'smir_angel@mymail.com', 'ул.Амосова д.35', '722416', 'AB722416', '1990/7/30')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Максимов', 'Егор', 3 ,'+7(921)277-33-99', 'maximov@mymail.com', 'ул.Соловьёваа д.50', '789216', 'AB789216', '1979/11/22')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Денисов', 'Владислав', 3 ,'+7(978)778-35-97', 'denisov@mymail.com', 'ул.Амосова д.71', '913942', 'AB913942', '1971/2/5')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Коновалов', 'Артур', 11,' +7(966)394-13-99', 'danilov_artur@mymail.com', 'ул.Смирноваа д.61', '959683', 'AB959683', '1980/11/7')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Данилов', 'Виталий', 2 ,'+7(919)335-14-18', 'danilov_vitalka@mymail.com', 'ул.Амосова д.41', '6446', 'AB6446', '1993/4/27')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Титова', 'Вероника', 7 ,'+7(961)475-86-21', 'titova@mymail.com', 'ул.Денисова д.46', '794991', 'AB794991', '1991/9/24')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Волкова', 'Олеся', 1 ,'+7(992)584-87-52', 'volkova@mymail.com', 'ул.Амосова д.68', '84215', 'AB84215', '1989/9/9')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Алексеева', 'Александра', 11,' +7(929)218-21-44', 'alexeeva@mymail.com', 'ул.Данилова д.53', '557609', 'AB557609', '1982/10/25')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Осипова', 'Эльвира', 5 ,'+7(972)819-35-27', 'osipova@mymail.com', 'ул.Амосова д.41', '972035', 'AB972035', '1969/3/9')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Щербаков', 'Мстислав', 10,' +7(998)648-91-39', 'scherbakova@mymail.com', 'ул.Амосова д.66', '261723', 'AB261723', '1995/11/25')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Карпова', 'Аделия', 5 ,'+7(922)647-76-41', 'karpova@mymail.com', 'ул.Амосова д.52', '366482', 'AB366482', '2006/9/10')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Миллер', 'Давид', 3 ,'+7(944)389-58-29', 'miller@mymail.com', 'ул.Денисова д.47', '701472', 'AB701472', '1980/6/18')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Быков', 'Виталий', 1 ,'+7(987)954-62-25', 'bikov@mymail.com', 'ул.Амосова д.55', '474916', 'AB474916', '1950/6/3')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Михайлова', 'Татьяна', 4 ,'+7(912)649-49-49', 'mikhailova@mymail.com', 'ул.Карповаа д.42', '128869', 'AB128869', '1968/3/29')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Прокофьев', 'Никита', 11,' +7(992)698-49-81', 'prokofiev@mymail.com', 'ул.Волковаа д.62', '351489', 'AB351489', '1973/4/25')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Гусев', 'Радислав', 5 ,'+7(932)865-46-44', 'gusev@mymail.com', 'ул.Денисова д.76', '224125', 'AB224125', '1954/2/20')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Сорокина', 'Динара', 6 ,'+7(987)162-12-77', 'sorokina@mymail.com', 'ул.Титоваа д.69', '794312', 'AB794312', '1954/10/29')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Трофимов', 'Анатолий', 5 ,'+7(983)912-99-15', 'trophimov@mymail.com', 'ул.Амосова д.55', '506992', 'AB506992', '2001/2/12')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Матвеев', 'Ваган', 1 ,'+7(968)921-36-87', 'matveev_vagan@mymail.com', 'ул.Амосова д.43', '54108', 'AB54108', '1952/5/18')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Фомина', 'Елена', 4 ,'+7(969)836-36-52', 'fomina@mymail.com', 'ул.Волковаа д.79', '325554', 'AB325554', '1999/10/12')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Воробьёв', 'Кирилл', 3 ,'+7(929)859-46-48', 'vorobievK@mymail.com', 'ул.Прокофьева д.36', '968498', 'AB968498', '1992/2/27')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Данилов', 'Виталий', 3 ,'+7(926)516-64-22', 'danilov_vit@mymail.com', 'ул.Прокофьева д.35', '937846', 'AB937846', '1998/10/26')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Никитина', 'Инна', 8 ,'+7(988)625-81-31', 'nikitina@mymail.com', 'ул.Амосова д.36', '554830', 'AB554830', '1964/8/16')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Полякова', 'Элина', 7 ,'+7(945)996-47-66', 'polyakova_all@mymail.com', 'ул.Данилова д.42', '656299', 'AB656299', '1967/8/21')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Борисов', 'Анатолий', 8 ,'+7(969)729-38-76', 'borisov@mymail.com', 'ул.Амосова д.47', '688460', 'AB688460', '1961/11/9')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Титов', 'Олесь', 7 ,'+7(951)782-35-69', 'titov@mymail.com', 'ул.Соловьёваа д.62', '913464', 'AB913464', '1979/3/23')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Кузьмина', 'Эльвира', 3 ,'+7(974)161-15-44', 'kuzmina_alya@mymail.com', 'ул.Данилова д.57', '10448', 'AB10448', '1980/5/14')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Кириллова', 'Аида', 3 ,'+7(924)155-91-39', 'kirilova@mymail.com', 'ул.Михайловаа д.39', '926236', 'AB926236', '1965/8/21')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Михайлов', 'Малик', 4 ,'+7(967)724-71-46', 'mikhailov@mymail.com', 'ул.Савельева д.44', '186652', 'AB186652', '1952/10/16')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Данилова', 'Екатерина', 3 ,'+7(968)186-19-51', 'danilova@mymail.com', 'ул.Амосова д.69', '860538', 'AB860538', '1966/2/16')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Яковлева', 'Юлиана', 9 ,'+7(913)923-87-91', 'yakovleva@mymail.com', 'ул.Поляковаа д.30', '311275', 'AB311275', '1964/3/6')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Титова', 'Сати', 3 ,'+7(953)723-49-84', 'titova_sati@mymail.com', 'ул.Прокофьева д.44', '145674', 'AB145674', '1956/3/16')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Голубева', 'Маргарита', 8 ,'+7(976)468-33-72', 'golubeva_m@mymail.com', 'ул.Александрова д.70', '303004', 'AB303004', '2007/12/4')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Дмитриева', 'Наталья', 10,' +7(951)897-81-45', 'dmitrieva@mymail.com', 'ул.Новикова д.51', '978015', 'AB978015', '1994/11/5')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Герасимова', 'Айжан', 1 ,'+7(943)869-65-73', 'gerasimova@mymail.com', 'ул.Денисова д.30', '924217', 'AB924217', '2006/4/15')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Титова', 'Анна', 6 ,'+7(962)638-89-82', 'titova_ann@mymail.com', 'ул.Дмитриеваа д.48', '319474', 'AB319474', '1977/2/15')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Троицкийа', 'Куралай', 4 ,'+7(956)984-62-63', 'troitskaya@mymail.com', 'ул.Трофимова д.59', '467460', 'AB467460', '1988/3/28')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Абрамов', 'Вадим', 8 ,'+7(945)388-49-67', 'abramov@mymail.com', 'ул.Амосова д.77', '235695', 'AB235695', '1973/6/7')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Лебедева', 'Дарига', 1 ,'+7(949)484-57-38', 'lebedeva@mymail.com', 'ул.Савельева д.39', '25244', 'AB25244', '1954/9/5')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Мартынова', 'Куралай', 3 ,'+7(959)297-92-81', 'martynova@mymail.com', 'ул.Волковаа д.63', '590277', 'AB590277', '1961/8/18')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Сидорова', 'Салтанат', 10,' +7(999)467-99-17', 'sidorova@mymail.com', 'ул.Амосова д.47', '315825', 'AB315825', '1986/5/15')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Карпова', 'Ярослава', 4 ,'+7(939)489-92-24', 'karpova@mymail.com', 'ул.Яковлеваа д.42', '626570', 'AB626570', '2007/4/6')
GO
INSERT INTO [dbo].[client]([first_name],[last_name],[city_id],[phone_number],[email],[adress],[passport],[foreign_passport],[birth_date])
	VALUES('Дмитриева', 'Гульназ', 9 ,'+7(927)654-92-34', 'dmitrieva@mymail.com', 'ул.Борисова д.62', '94671', 'AB94671', '1993/4/8')
GO