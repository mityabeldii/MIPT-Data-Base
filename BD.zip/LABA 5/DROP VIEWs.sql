IF OBJECT_ID ('laba5_1') IS NOT NULL
    DROP VIEW laba5_1;
GO

IF OBJECT_ID ('laba5_2') IS NOT NULL
    DROP VIEW laba5_2;
GO

IF OBJECT_ID ('laba5_3') IS NOT NULL
    DROP VIEW laba5_3;
GO

IF OBJECT_ID ('laba5_4') IS NOT NULL
    DROP VIEW laba5_4;
GO

IF OBJECT_ID ('laba5_5') IS NOT NULL
    DROP VIEW laba5_5;
GO

IF OBJECT_ID ('laba5_6') IS NOT NULL
    DROP VIEW laba5_6;
GO

IF OBJECT_ID ('laba5_7') IS NOT NULL
    DROP VIEW laba5_7;
GO

IF OBJECT_ID ('laba5_8') IS NOT NULL
    DROP VIEW laba5_8;
GO