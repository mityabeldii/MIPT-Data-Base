WITH excesshotels AS (SELECT hotels.hotel_id
FROM hotels, offer, resort
WHERE offer.resort_id = resort.resort_id
	AND resort.hotel_id = hotels.hotel_id
	AND (MONTH(offer.end_date) < 10)
	AND (MONTH(offer.end_date) > 4)
	AND (YEAR(offer.end_date) = YEAR(offer.start_date))
	AND (YEAR(offer.end_date) = YEAR(GETDATE()))
GROUP BY hotels.hotel_id), hot AS (SELECT TOP(SELECT COUNT(hotel_id)/3 FROM excesshotels) hotel_id
FROM excesshotels)

DELETE FROM offer, resort, hotels
WHERE offer.resort_id = resort.resort_id
	AND resort.hotel_id = hotels.hotel_id
	AND hotels.hotel_id IN (SELECT hotel_id FROM hot)

DELETE FROM resort, hotels
WHERE resort.hotel_id = hotels.hotel_id
	ANd hotels.hotel_id IN (SELECT hotel_id FROM hot)

DELETE FROM hotels
WHERE hotel_id IN (SELECT hotel_id FROM hot)