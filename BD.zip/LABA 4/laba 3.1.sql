SELECT TOP(1) WITH TIES client.first_name, client.last_name, client.client_id, COUNT(offer.offer_id) as CNT, SUM(offer.price) as TOTAL_COST
FROM offer, resort, country, client
WHERE offer.resort_id = resort.resort_id
	and resort.country_id = country.country_id
	and country.name = 'Египет'
	and offer.client_id = client.client_id
GROUP BY client.client_id,first_name, last_name
ORDER BY COUNT(offer.offer_id) DESC, SUM(offer.price)

--Выбрать отдыхающего, наибольшее число раз посетившего 'Египет', это количество и его затраты на поездки.