SELECT oa.price, ha.name, NULL, NULL
FROM offer oa, resort ra, seas sa, hotels ha
WHERE oa.price = 3000
	AND oa.resort_id = ra.resort_id
	AND ra.sea_id = sa.sea_id
	AND sa.name = 'Средиземное море'
	AND ra.hotel_id = ha.hotel_id
UNION
SELECT oa.price, ha.name, ob.price, hb.name
FROM offer oa, offer ob, resort ra, resort rb, seas sa, seas sb, hotels ha, hotels hb
WHERE oa.price + ob.price = 3000
	AND oa.offer_id != ob.offer_id
	AND oa.resort_id = ra.resort_id
	AND ra.sea_id = sa.sea_id
	AND sa.name = 'Средиземное море'
	AND ob.resort_id = rb.resort_id
	AND rb.sea_id = sb.sea_id
	AND sb.name = 'Средиземное море'
	AND ra.hotel_id = ha.hotel_id
	AND rb.hotel_id = hb.hotel_id

--Выбрать все возможные варианты не более двух тур-поездок на сумму 3000, так чтобы отдых прошел на 'Средиземном' море.