SELECT seas.name, hotels.name
FROM offer, seas, client, resort, hotels
WHERE offer.client_id = client.client_id
	and offer.resort_id = resort.resort_id
	and resort.sea_id = seas.sea_id
	and resort.hotel_id = hotels.hotel_id
	and client.first_name = 'Коновалов'
	and year(offer.start_date) = year(GETDATE()) - 1

	--Выбрать моря и названия отелей, которые посетил 'Коновалов' в прошлом году.