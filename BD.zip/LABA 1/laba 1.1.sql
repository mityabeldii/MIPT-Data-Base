SELECT description
FROM PRODUCT, PRICE
WHERE PRODUCT.product_id=PRICE.product_id
	and (YEAR(GETDATE())-YEAR(start_date))>3
GROUP BY description