SELECT first_name, middle_initial, last_name
FROM EMPLOYEE, CUSTOMER, SALES_ORDER
WHERE EMPLOYEE.employee_id=CUSTOMER.salesperson_id
	and CUSTOMER.customer_id=SALES_ORDER.customer_id
	and YEAR(order_date)=1989
GROUP BY first_name, middle_initial, last_name 
HAVING SUM(total)>=1000
	and COUNT(order_id)>=5