SELECT first_name, middle_initial, last_name, commission, salary FROM EMPLOYEE
WHERE commission IS NOT NULL
	and salary+isnull(commission,0)>1500
	and datediff(MONTH, hire_date, GETDATE())>60