SELECT TOP(1) first_name, COUNT(employee_id) as employees
FROM EMPLOYEE
WHERE 1989-YEAR(hire_date)<=4
	and manager_id is not NULL
GROUP BY manager_id, first_name
ORDER BY employees DESC