CREATE TABLE AUX (
	a integer
);
INSERT INTO AUX VALUES (1)


SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN TRANSACTION

UPDATE AUX SET a = (SELECT classifiacation FROM hotels WHERE hotel_id = 1)
SELECT * FROM AUX

UPDATE hotels SET classifiacation = a + 1 FROM AUX WHERE hotel_id = 1

COMMIT

SELECT classifiacation FROM hotels WHERE hotel_id = 1
UPDATE hotels SET classifiacation = 3 WHERE hotel_id = 1

DROP TABLE AUX
