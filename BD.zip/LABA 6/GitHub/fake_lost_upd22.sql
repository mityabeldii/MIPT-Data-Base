DECLARE @SafetyStockLevel int = 0
,@Uplift int = 100;

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED 

BEGIN TRAN

SELECT classifiacation FROM hotels
WHERE hotel_id = 1;

SET @SafetyStockLevel = @SafetyStockLevel + @Uplift;

UPDATE hotels
SET classifiacation = @SafetyStockLevel
WHERE hotel_id = 1;
SELECT classifiacation FROM hotels
WHERE hotel_id = 1;
COMMIT TRAN;