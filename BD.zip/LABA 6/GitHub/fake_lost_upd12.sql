DECLARE @SafetyStockLevel int = 0
,@Uplift int = 5;

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN TRAN

SELECT classifiacation FROM HOTELS
WHERE hotel_id = 1;

SET @SafetyStockLevel = @SafetyStockLevel + @Uplift;
WAITFOR DELAY '00:00:05.000';

UPDATE HOTELS
SET classifiacation = @SafetyStockLevel
WHERE hotel_id = 1;

SELECT classifiacation FROM hotels
WHERE hotel_id = 1;

COMMIT TRAN;