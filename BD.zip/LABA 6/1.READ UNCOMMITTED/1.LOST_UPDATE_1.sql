SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
BEGIN TRANSACTION
	SELECT classifiacation  FROM hotels 
	WHERE hotel_id = 1

	UPDATE hotels
	SET classifiacation  = classifiacation  - 1
	WHERE hotel_id = 1
COMMIT;

	SELECT classifiacation  FROM hotels 
	WHERE hotel_id = 1
