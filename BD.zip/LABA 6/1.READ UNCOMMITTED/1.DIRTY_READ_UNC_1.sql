SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
BEGIN TRANSACTION
	SELECT classifiacation FROM hotels 
	WHERE hotel_id = 1

	SELECT classifiacation FROM hotels
	WHERE hotel_id = 1

	SELECT classifiacation FROM hotels
	WHERE hotel_id = 1
COMMIT