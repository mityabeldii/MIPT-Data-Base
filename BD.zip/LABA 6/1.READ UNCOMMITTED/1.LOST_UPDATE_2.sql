SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
BEGIN TRANSACTION
	SELECT classifiacation  FROM hotels 
	WHERE hotel_id = 1

	UPDATE hotels
	SET classifiacation  = classifiacation  - 2
	WHERE hotel_id = 1
COMMIT;

	SELECT classifiacation  FROM hotels 
	WHERE hotel_id = 1